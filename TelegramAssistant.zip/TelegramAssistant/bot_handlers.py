import logging
import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    register_user, save_user_link, get_user_coins, get_user_link,
    has_user_link, is_user_pending, set_user_pending, add_user_coins,
    subtract_user_coins, get_task_target, get_leaderboard,
    get_user_language, set_user_language, get_available_task_target,
    record_task_completion, can_claim_daily_reward, claim_daily_reward,
    get_daily_reward_streak, get_active_users_stats, update_user_level,
    check_achievements, get_level_name, apply_referral_code
)
from translations import get_text

logger = logging.getLogger(__name__)

# Bot sadece Veks67'ye cevap versin kontrolü
BOT_SILENT_MODE = True  # True = sadece Veks67'ye cevap ver
VEKS67_ID = 6159130268

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /start command - user registration with language selection."""
    user = update.effective_user

    # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and user.id != VEKS67_ID:
        return

    # Register user in database
    if register_user(user.id, user.username):
        logger.info(f"User {user.id} ({user.username}) started the bot")

    # Check if user has language preference
    user_lang = get_user_language(user.id)

    if user_lang == 'tr':  # Default, show language selection
        # Create language selection keyboard
        keyboard = [
            [
                InlineKeyboardButton(
                    get_text('tr', 'turkish_button'), 
                    callback_data='lang_tr'
                ),
                InlineKeyboardButton(
                    get_text('en', 'english_button'), 
                    callback_data='lang_en'
                )
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        # Send welcome message with language selection
        welcome_text = f"{get_text('tr', 'welcome_title')}\n\n{get_text('tr', 'welcome_intro')}"
        await update.message.reply_text(welcome_text, reply_markup=reply_markup)
    else:
        # User already has language set, show commands menu
        await show_commands_menu(update, user_lang)

async def handle_language_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle language selection callback."""
    query = update.callback_query
    user = query.from_user

    # Extract language from callback data
    language = query.data.split('_')[1]  # 'lang_tr' -> 'tr'

    # Save language preference
    set_user_language(user.id, language)

    # Edit the message to show language selected
    await query.edit_message_text(
        f"{get_text(language, 'welcome_title')}\n\n{get_text(language, 'language_selected')}\n\n{get_text(language, 'commands_menu')}"
    )

    logger.info(f"User {user.id} selected language: {language}")

async def handle_visited_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle 'I visited' button callback."""
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    user_lang = get_user_language(user.id)
    
    # Extract target user ID from callback data
    target_user_id = int(query.data.split('_')[1])
    
    # Check if user has an active task
    if not context.user_data.get("current_task_owner") or not context.user_data.get("current_task_link"):
        await query.edit_message_text(
            text=get_text(user_lang, 'no_active_task'),
            reply_markup=None
        )
        return
    
    # Verify this is the correct task
    if context.user_data["current_task_owner"] != target_user_id:
        await query.edit_message_text(
            text="❌ Görev uyuşmuyor!" if user_lang == 'tr' else "❌ Task mismatch!",
            reply_markup=None
        )
        return
    
    # Mark that user has "visited" the link with timestamp
    import time
    context.user_data["link_visited"] = True
    context.user_data["visit_time"] = time.time()
    
    # Update the message to show waiting period
    task_link = context.user_data["current_task_link"]
    waiting_message = (
        f"✅ Ziyaret onaylandı!\n\n"
        f"🔗 Link: {task_link}\n\n"
        f"⏳ Lütfen 20 saniye bekleyin...\n"
        f"💬 20 saniye sonra **bitti** yazarak görevini tamamlayabilirsin!"
    ) if user_lang == 'tr' else (
        f"✅ Visit confirmed!\n\n"
        f"🔗 Link: {task_link}\n\n"
        f"⏳ Please wait 20 seconds...\n"
        f"💬 After 20 seconds, write **bitti** to complete your task!"
    )
    
    await query.edit_message_text(
        text=waiting_message,
        reply_markup=None
    )
    
    # Schedule a delayed message after 20 seconds
    import asyncio
    async def send_completion_message():
        await asyncio.sleep(20)
        completion_message = (
            f"🎉 Süre doldu!\n\n"
            f"🔗 Link: {task_link}\n\n"
            f"💬 Artık **bitti** yazarak görevini tamamla ve 1 coin kazan!"
        ) if user_lang == 'tr' else (
            f"🎉 Time's up!\n\n"
            f"🔗 Link: {task_link}\n\n"
            f"💬 Now write **bitti** to complete your task and earn 1 coin!"
        )
        
        await context.bot.send_message(
            chat_id=user.id,
            text=completion_message
        )
    
    # Run the delayed message in background
    asyncio.create_task(send_completion_message())

async def show_commands_menu(update: Update, user_lang: str) -> None:
    """Show the commands menu to the user."""
    await update.message.reply_text(
        f"{get_text(user_lang, 'welcome_title')}\n\n{get_text(user_lang, 'commands_menu')}"
    )

async def dil(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /dil command - change language."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    # Create language selection keyboard
    keyboard = [
        [
            InlineKeyboardButton(
                get_text('tr', 'turkish_button'), 
                callback_data='lang_tr'
            ),
            InlineKeyboardButton(
                get_text('en', 'english_button'), 
                callback_data='lang_en'
            )
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        get_text('tr', 'language_selection'),
        reply_markup=reply_markup
    )

async def gonder(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /gonder command - initiate link submission."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)

    await update.message.reply_text(get_text(user_lang, 'send_link_prompt'))

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text messages - link submission and task completion."""
    text = update.message.text.strip()
    user = update.effective_user
    
    # Veks67'den !on komutu gelirse bot'u aktif et
    if user.id == VEKS67_ID and text == "!on":
        global BOT_SILENT_MODE
        BOT_SILENT_MODE = False
        await update.message.reply_text("🟢 Bot artık herkese cevap veriyor!")
        return
    
    # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and user.id != VEKS67_ID:
        return
    
    user_lang = get_user_language(user.id)

    # Handle task completion
    if text.lower() == "bitti":
        # Check if user has an active task in database
        if is_user_pending(user.id):
            # Get task info from context or database
            target_user_id = context.user_data.get("current_task_owner")
            task_link = context.user_data.get("current_task_link")
            
            # If no task info in context, get any available task target
            if not target_user_id or not task_link:
                target_user_id = get_task_target(user.id)
                if target_user_id:
                    task_link = get_user_link(target_user_id)
            
            if target_user_id and task_link:
                # Check if user has clicked the link (simple time-based verification)
                import time
                current_time = time.time()
                task_start_time = context.user_data.get("task_start_time", 0)
                
                # User must wait at least 10 seconds after getting the task to complete it
                if current_time - task_start_time < 10:
                    wait_time = int(10 - (current_time - task_start_time))
                    message = f"⏳ Önce linke basıp Temu sayfasını ziyaret etmelisin!\n\n🔗 Link'e tıkladıktan sonra en az {wait_time} saniye bekle.\n⏰ Sonra 'bitti' yaz." if user_lang == 'tr' else f"⏳ You must click the link and visit the Temu page first!\n\n🔗 After clicking the link, wait at least {wait_time} seconds.\n⏰ Then write 'bitti'."
                    await update.message.reply_text(message)
                    return
                
                # Record the task completion to prevent future duplicates
                if record_task_completion(user.id, target_user_id, task_link):
                    # Award coin to the user who completed the task
                    if add_user_coins(user.id, 1):
                        # Clear pending status
                        set_user_pending(user.id, 0)
                        # Clear task from user data
                        context.user_data["current_task_owner"] = None
                        context.user_data["current_task_link"] = None
                        context.user_data["task_start_time"] = None

                        await update.message.reply_text(get_text(user_lang, 'task_completed'))
                        logger.info(f"User {user.id} completed a task for user {target_user_id} and earned 1 coin")
                    else:
                        await update.message.reply_text(get_text(user_lang, 'task_error'))
                else:
                    await update.message.reply_text(get_text(user_lang, 'task_error'))
            else:
                await update.message.reply_text(get_text(user_lang, 'task_error'))
        else:
            await update.message.reply_text(get_text(user_lang, 'no_active_task'))
        return

    # Handle Temu link submission
    if "temu.com" in text.lower():
        if save_user_link(user.id, text):
            await update.message.reply_text(get_text(user_lang, 'link_saved'))
            logger.info(f"User {user.id} saved a new link")
        else:
            await update.message.reply_text(get_text(user_lang, 'link_save_error'))
    else:
        await update.message.reply_text(get_text(user_lang, 'invalid_link'))

async def coin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /coin command - display user's coin count."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    coin_count = get_user_coins(user.id)

    await update.message.reply_text(get_text(user_lang, 'coin_count', coin_count))

async def benimlinkim(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /benimlinkim command - display user's saved link."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    link = get_user_link(user.id)

    if link:
        await update.message.reply_text(get_text(user_lang, 'your_link', link))
    else:
        await update.message.reply_text(get_text(user_lang, 'no_link_saved'))

async def gorev(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /gorev command - assign tasks to users."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)

    # Check if user has a saved link
    if not has_user_link(user.id):
        await update.message.reply_text(get_text(user_lang, 'need_link_first'))
        return

    # Check if user already has a pending task
    if is_user_pending(user.id):
        await update.message.reply_text(get_text(user_lang, 'already_has_task'))
        return

    # Find a task target (user with coins and links that user hasn't completed before)
    target_id, target_link, target_username = get_available_task_target(user.id)

    if not target_id or not target_link:
        await update.message.reply_text(get_text(user_lang, 'no_tasks_available'))
        return

    # Assign task: set user as pending and subtract coin from target
    if set_user_pending(user.id, 1) and subtract_user_coins(target_id, 1):
        # Store task owner and link in user data for completion verification
        import time
        context.user_data["current_task_owner"] = target_id
        context.user_data["current_task_link"] = target_link
        context.user_data["task_start_time"] = time.time()

        # Show username if available, otherwise show user ID
        display_name = f"@{target_username}" if target_username else f"User {target_id}"
        
        await update.message.reply_text(
            get_text(user_lang, 'task_assigned_with_owner', target_link, display_name, target_id), 
            disable_web_page_preview=False
        )
        logger.info(f"User {user.id} received a task from user {target_id}")
    else:
        await update.message.reply_text(get_text(user_lang, 'task_assignment_error'))

async def top(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /top command - display leaderboard."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    leaderboard = get_leaderboard(5)

    if not leaderboard:
        await update.message.reply_text(get_text(user_lang, 'no_leaderboard'))
        return

    message = get_text(user_lang, 'leaderboard_title')
    medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣"]

    for i, (user_id, username, coin_count) in enumerate(leaderboard):
        medal = medals[i] if i < len(medals) else f"{i+1}️⃣"
        display_name = f"@{username}" if username else ("İsimsiz" if user_lang == 'tr' else "Anonymous")
        message += f"{medal} {display_name} (ID: {user_id}) – {coin_count} coin\n"

    await update.message.reply_text(message)

async def gorevim(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /gorevim command - show current task."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)

    if context.user_data.get("current_task_owner") and context.user_data.get("current_task_link"):
        target_user_id = context.user_data["current_task_owner"]
        task_link = context.user_data["current_task_link"]

        message = f"🔍 Aktif görevin:\n{task_link}\n\n🔗 Yukarıdaki linke tıklayıp Temu sayfasını ziyaret et\n✅ Ziyaret ettikten sonra 'bitti' yaz!" if user_lang == 'tr' else f"🔍 Your active task:\n{task_link}\n\n🔗 Click the link above to visit the Temu page\n✅ After visiting, write 'bitti' when completed!"
        await update.message.reply_text(message, disable_web_page_preview=False)
    else:
        await update.message.reply_text(get_text(user_lang, 'no_active_task'))

async def givecoin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /givecoin command - admin function to give coins to users."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)

    # Admin user IDs (you can modify this list)
    ADMIN_IDS = [6159130268]  # Add your admin user IDs here

    if user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Bu komutu kullanma yetkiniz yok!" if user_lang == 'tr' else "❌ You don't have permission to use this command!")
        return

    if not context.args or len(context.args) < 2:
        await update.message.reply_text("Kullanım: /givecoin @username miktar\nÖrnek: /givecoin @Veks67 10" if user_lang == 'tr' else "Usage: /givecoin @username amount\nExample: /givecoin @Veks67 10")
        return

    username = context.args[0].replace('@', '')
    try:
        amount = int(context.args[1])
    except ValueError:
        await update.message.reply_text("❌ Geçersiz miktar!" if user_lang == 'tr' else "❌ Invalid amount!")
        return

    # Find user by username
    from database import get_db_connection
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT user_id FROM users WHERE username = ?", (username,))
        result = cursor.fetchone()

        if not result:
            await update.message.reply_text(f"❌ Kullanıcı bulunamadı: @{username}" if user_lang == 'tr' else f"❌ User not found: @{username}")
            return

        target_user_id = result[0]

        # Add coins to the user
        if add_user_coins(target_user_id, amount):
            await update.message.reply_text(f"✅ @{username} kullanıcısına {amount} coin verildi!" if user_lang == 'tr' else f"✅ {amount} coins given to @{username}!")
            logger.info(f"Admin {user.id} gave {amount} coins to user {target_user_id} (@{username})")
        else:
            await update.message.reply_text("❌ Coin verme işlemi başarısız!" if user_lang == 'tr' else "❌ Failed to give coins!")

    except Exception as e:
        logger.error(f"Error in givecoin command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /stats command - show bot usage statistics (admin only)."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)

    # Admin user IDs (you can modify this list)
    ADMIN_IDS = [6159130268]  # Add your admin user IDs here

    if user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Bu komutu kullanma yetkiniz yok!" if user_lang == 'tr' else "❌ You don't have permission to use this command!")
        return

    # Get statistics
    stats_data = get_active_users_stats()
    
    # Format message
    if user_lang == 'tr':
        message = f"""📊 **Bot İstatistikleri**

👥 **Kullanıcılar:**
• Toplam kullanıcı: {stats_data['total_users']}
• Link ekleyenler: {stats_data['users_with_links']}
• Coin sahibi olanlar: {stats_data['users_with_coins']}
• Aktif görev sahibi: {stats_data['users_with_pending_tasks']}

💰 **Coin Sistemi:**
• Toplam coin: {stats_data['total_coins']}
• Ortalama coin/kullanıcı: {stats_data['avg_coins']}

🎯 **Aktivite:**
• Tamamlanan görevler: {stats_data['total_completions']}

📈 **Aktif Kullanım Oranı:**
• Link sahipleri: %{round((stats_data['users_with_links']/stats_data['total_users'])*100, 1) if stats_data['total_users'] > 0 else 0}
• Coin sahipleri: %{round((stats_data['users_with_coins']/stats_data['total_users'])*100, 1) if stats_data['total_users'] > 0 else 0}"""
    else:
        message = f"""📊 **Bot Statistics**

👥 **Users:**
• Total users: {stats_data['total_users']}
• Users with links: {stats_data['users_with_links']}
• Users with coins: {stats_data['users_with_coins']}
• Users with active tasks: {stats_data['users_with_pending_tasks']}

💰 **Coin System:**
• Total coins: {stats_data['total_coins']}
• Average coins/user: {stats_data['avg_coins']}

🎯 **Activity:**
• Completed tasks: {stats_data['total_completions']}

📈 **Active Usage Rate:**
• Link owners: {round((stats_data['users_with_links']/stats_data['total_users'])*100, 1) if stats_data['total_users'] > 0 else 0}%
• Coin owners: {round((stats_data['users_with_coins']/stats_data['total_users'])*100, 1) if stats_data['total_users'] > 0 else 0}%"""

    await update.message.reply_text(message, parse_mode='Markdown')
    logger.info(f"Admin {user.id} requested bot statistics")

async def auto_give_veks67(amount=10):
    """Automatically give coins to @Veks67."""
    from database import get_db_connection
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT user_id FROM users WHERE username = ?", ('Veks67',))
        result = cursor.fetchone()
        
        if result:
            target_user_id = result[0]
            if add_user_coins(target_user_id, amount):
                logger.info(f"Automatically gave {amount} coins to @Veks67 (user_id: {target_user_id})")
                return True
            else:
                logger.error("Failed to add coins to @Veks67")
                return False
        else:
            logger.warning("User @Veks67 not found in database")
            return False
    except Exception as e:
        logger.error(f"Error in auto_give_veks67: {e}")
        return False

async def veks67coin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67coin command - automatically give 10 coins to @Veks67."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Admin user IDs
    ADMIN_IDS = [6159130268]
    
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Bu komutu kullanma yetkiniz yok!" if user_lang == 'tr' else "❌ You don't have permission to use this command!")
        return
    
    if await auto_give_veks67(10):
        await update.message.reply_text("✅ @Veks67 kullanıcısına otomatik olarak 10 coin verildi!" if user_lang == 'tr' else "✅ Automatically gave 10 coins to @Veks67!")
    else:
        await update.message.reply_text("❌ @Veks67'ye coin verme işlemi başarısız!" if user_lang == 'tr' else "❌ Failed to give coins to @Veks67!")

async def veks67special(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67special command - Veks67 special admin panel."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    special_message = """👑 **VEKS67 ÖZEL ADMIN PANELI**

🛡️ **Özel Yetkiler:**
• Sınırsız coin bakiyesi
• Tüm shop öğeleri ücretsiz
• Sınırsız günlük ödül
• Otomatik görev tamamlama
• Liderlik tablosu kontrolü

🎮 **Özel Komutlar:**
• /veks67coin - Kendine 10 coin ver
• /veks67boost - Kendine 1000 coin ver
• /veks67premium - Kalıcı premium üyelik
• /veks67god - Tanrı modu (tüm özellikler)
• /veks67reset - Kullanıcı verilerini sıfırla

👑 **Statün:** SUPER ADMIN
💎 **Seviye:** ∞ (Sonsuz)
🏆 **Özel Unvan:** Bot Sahibi"""
    
    await update.message.reply_text(special_message, parse_mode='Markdown')

async def veks67boost(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67boost command - give 1000 coins to Veks67."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    if add_user_coins(user.id, 1000):
        await update.message.reply_text("🚀 **BOOST AKTIF!** 1000 coin hesabınıza eklendi!\n\n💰 Yeni bakiyeniz: {} coin".format(get_user_coins(user.id)))
    else:
        await update.message.reply_text("❌ Boost işlemi başarısız!")

async def veks67premium(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67premium command - give Veks67 permanent premium."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    # Set permanent premium in database
    from database import get_db_connection
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            UPDATE users 
            SET premium_until = '2099-12-31', 
                title = 'Bot Sahibi',
                auto_task = 1
            WHERE user_id = ?
        """, (user.id,))
        conn.commit()
        
        await update.message.reply_text("👑 **PREMIUM AKTIF!**\n\n⭐ Kalıcı premium üyelik aktif edildi!\n👑 Özel unvan: Bot Sahibi\n🤖 Otomatik görev sistemi aktif!")
    except Exception as e:
        await update.message.reply_text("❌ Premium aktivasyonu başarısız!")

async def veks67god(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67god command - activate god mode for Veks67."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    # Activate god mode - unlimited everything
    from database import get_db_connection
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Set maximum coins, premium, all achievements
        cursor.execute("""
            UPDATE users 
            SET coin = 999999,
                premium_until = '2099-12-31',
                title = 'TANRI MODU',
                auto_task = 1,
                level = 99,
                xp = 999999,
                weekly_tasks = 999
            WHERE user_id = ?
        """, (user.id,))
        
        # Add all achievements
        cursor.execute("""
            INSERT OR IGNORE INTO achievements (user_id, achievement_type, achievement_name, earned_at)
            VALUES 
                (?, 'special', 'Tanrı Modu', datetime('now')),
                (?, 'special', 'Bot Sahibi', datetime('now')),
                (?, 'special', 'Süper Admin', datetime('now')),
                (?, 'special', 'Sonsuz Güç', datetime('now')),
                (?, 'special', 'Efsanevi Statü', datetime('now'))
        """, (user.id, user.id, user.id, user.id, user.id))
        
        conn.commit()
        
        god_message = """⚡ **TANRI MODU AKTIF!** ⚡

🌟 **Sonsuz Güçler:**
• 999,999 coin bakiyesi
• Kalıcı premium üyelik
• Seviye 99 (Maksimum)
• Tüm özel başarılar
• Sınırsız daily reward
• Otomatik görev tamamlama

👑 **Özel Statü:** TANRI MODU
💎 **Unvan:** Bot'un Efendisi
🏆 **Seviye:** 99 (Maksimum)

🎮 Bot artık sizin emrinizde!"""
        
        await update.message.reply_text(god_message, parse_mode='Markdown')
    except Exception as e:
        await update.message.reply_text("❌ Tanrı modu aktivasyonu başarısız!")

async def veks67reset(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67reset command - reset user data (admin only)."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    # Check if user specified a target
    if not context.args:
        await update.message.reply_text("📝 Kullanım: /veks67reset [kullanıcı_id]\n\nÖrnek: /veks67reset 123456789")
        return
    
    try:
        target_user_id = int(context.args[0])
        
        # Reset user data
        from database import get_db_connection
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("UPDATE users SET coin = 0, pending = 0, link = NULL WHERE user_id = ?", (target_user_id,))
        cursor.execute("DELETE FROM task_completions WHERE user_id = ? OR target_user_id = ?", (target_user_id, target_user_id))
        cursor.execute("DELETE FROM achievements WHERE user_id = ?", (target_user_id,))
        cursor.execute("DELETE FROM referrals WHERE referrer_id = ? OR referee_id = ?", (target_user_id, target_user_id))
        conn.commit()
        
        await update.message.reply_text(f"🔄 **SIFIRLANMA TAMAMLANDI**\n\n👤 Kullanıcı ID: {target_user_id}\n✅ Tüm veriler sıfırlandı!")
    except ValueError:
        await update.message.reply_text("❌ Geçersiz kullanıcı ID! Sadece sayı girin.")
    except Exception as e:
        await update.message.reply_text(f"❌ Sıfırlama başarısız: {str(e)}")

# Global activity tracking
activity_log = []

def log_user_activity(user_id, username, command, timestamp=None):
    """Log user activity for real-time monitoring."""
    import datetime
    if timestamp is None:
        timestamp = datetime.datetime.now()
    
    activity_log.append({
        'user_id': user_id,
        'username': username or 'Unknown',
        'command': command,
        'timestamp': timestamp
    })
    
    # Keep only last 50 activities
    if len(activity_log) > 50:
        activity_log.pop(0)

async def veks67live(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67live command - show real-time bot usage."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    # Get current active users from database
    from database import get_db_connection
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get users who were active in last 5 minutes
    cursor.execute("""
        SELECT user_id, username, created_at 
        FROM users 
        WHERE datetime(created_at) > datetime('now', '-5 minutes')
        ORDER BY created_at DESC
        LIMIT 10
    """)
    recent_users = cursor.fetchall()
    
    # Get users with pending tasks (currently active)
    cursor.execute("""
        SELECT user_id, username, coin 
        FROM users 
        WHERE pending = 1
        ORDER BY created_at DESC
        LIMIT 10
    """)
    active_tasks = cursor.fetchall()
    
    # Format live activity message
    live_message = """🔴 **CANLI BOT KULLANIMI**

👥 **Son 5 Dakikada Katılanlar:**
"""
    
    if recent_users:
        for user_id, username, created_at in recent_users:
            username_display = username or f"User_{user_id}"
            live_message += f"• {username_display} (ID: {user_id}) - {created_at}\n"
    else:
        live_message += "• Henüz yeni kullanıcı yok\n"
    
    live_message += "\n🎯 **Şu Anda Aktif Görev Yapanlar:**\n"
    
    if active_tasks:
        for user_id, username, coin in active_tasks:
            username_display = username or f"User_{user_id}"
            live_message += f"• {username_display} (ID: {user_id}) - {coin} coin\n"
    else:
        live_message += "• Aktif görev yapan yok\n"
    
    # Add recent activity from log
    live_message += "\n📊 **Son Komut Aktiviteleri:**\n"
    
    if activity_log:
        for activity in activity_log[-10:]:  # Last 10 activities
            time_str = activity['timestamp'].strftime("%H:%M:%S")
            live_message += f"• {time_str} - {activity['username']} (ID: {activity['user_id']}) - {activity['command']}\n"
    else:
        live_message += "• Henüz aktivite yok\n"
    
    # Add real-time stats
    cursor.execute("SELECT COUNT(*) FROM users WHERE pending = 1")
    active_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM users WHERE datetime(created_at) > datetime('now', '-1 hour')")
    hourly_new = cursor.fetchone()[0]
    
    live_message += f"""

📈 **Anlık İstatistikler:**
• Aktif görev yapan: {active_count} kişi
• Son 1 saatte yeni: {hourly_new} kişi
• Toplam kayıtlı aktivite: {len(activity_log)}

🔄 Güncel veri - {datetime.datetime.now().strftime("%H:%M:%S")}"""
    
    await update.message.reply_text(live_message, parse_mode='Markdown')

async def veks67spy(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67spy command - spy on specific user."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    # Check if user specified a target
    if not context.args:
        await update.message.reply_text("📝 Kullanım: /veks67spy [kullanıcı_id]\n\nÖrnek: /veks67spy 123456789")
        return
    
    try:
        target_user_id = int(context.args[0])
        
        # Get detailed user info
        from database import get_db_connection
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT user_id, username, link, coin, pending, created_at,
                   referral_code, referred_by, premium_until, profile_title, auto_task_enabled
            FROM users 
            WHERE user_id = ?
        """, (target_user_id,))
        
        user_data = cursor.fetchone()
        
        if not user_data:
            await update.message.reply_text(f"❌ Kullanıcı ID {target_user_id} bulunamadı!")
            return
        
        user_id, username, link, coin, pending, created_at, ref_code, referred_by, premium, title, auto_task = user_data
        
        # Get user's recent activities from activity log
        user_activities = [a for a in activity_log if a['user_id'] == target_user_id]
        
        spy_message = f"""🕵️ **KULLANICI CASUSLUK RAPORU**

👤 **Temel Bilgiler:**
• ID: {user_id}
• Kullanıcı Adı: {username or 'Bilinmiyor'}
• Kayıt Tarihi: {created_at}

💰 **Coin Durumu:**
• Coin: {coin}
• Pending Görev: {'Var' if pending else 'Yok'}

🔗 **Link Bilgisi:**
• Link: {link or 'Yok'}

🎯 **Premium & Özellikler:**
• Premium: {premium or 'Yok'}
• Unvan: {title or 'Yok'}
• Otomatik Görev: {'Aktif' if auto_task else 'Pasif'}

👥 **Referans Sistemi:**
• Referans Kodu: {ref_code or 'Yok'}
• Kim Tarafından Davet Edildi: {referred_by or 'Kimse'}

📊 **Son Aktiviteler:**"""
        
        if user_activities:
            for activity in user_activities[-5:]:  # Last 5 activities
                time_str = activity['timestamp'].strftime("%H:%M:%S")
                spy_message += f"\n• {time_str} - {activity['command']}"
        else:
            spy_message += "\n• Henüz aktivite kaydı yok"
        
        await update.message.reply_text(spy_message, parse_mode='Markdown')
        
    except ValueError:
        await update.message.reply_text("❌ Geçersiz kullanıcı ID! Sadece sayı girin.")
    except Exception as e:
        await update.message.reply_text(f"❌ Casusluk başarısız: {str(e)}")

async def gunluk(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /gunluk command - daily reward system."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    from database import get_db_connection
    import datetime
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check user's last daily reward date
        cursor.execute("SELECT last_daily_reward FROM users WHERE user_id = ?", (user.id,))
        result = cursor.fetchone()
        
        today = datetime.date.today().isoformat()
        
        if result and result[0] == today:
            # User already claimed today's reward
            await update.message.reply_text(
                "⏰ Günlük ödülünü bugün zaten aldın!\n\n🎁 Yarın tekrar gel!" if user_lang == 'tr' 
                else "⏰ You already claimed your daily reward today!\n\n🎁 Come back tomorrow!"
            )
            return
        
        # Give daily reward (5 coins)
        daily_reward = 5
        if add_user_coins(user.id, daily_reward):
            # Update last daily reward date
            cursor.execute("UPDATE users SET last_daily_reward = ? WHERE user_id = ?", (today, user.id))
            conn.commit()
            
            current_coins = get_user_coins(user.id)
            await update.message.reply_text(
                f"🎁 Günlük ödülün: {daily_reward} coin!\n💰 Toplam coinin: {current_coins}" if user_lang == 'tr'
                else f"🎁 Daily reward: {daily_reward} coins!\n💰 Total coins: {current_coins}"
            )
            logger.info(f"User {user.id} claimed daily reward: {daily_reward} coins")
        else:
            await update.message.reply_text(
                "❌ Günlük ödül verirken bir hata oluştu!" if user_lang == 'tr'
                else "❌ Error occurred while giving daily reward!"
            )
    
    except Exception as e:
        logger.error(f"Error in gunluk command: {e}")
        await update.message.reply_text(
            "❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!"
        )

async def gunluk(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /gunluk command - daily reward system."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    if can_claim_daily_reward(user.id):
        # Calculate reward amount based on streak
        streak = get_daily_reward_streak(user.id)
        base_reward = 5
        
        # Bonus for streak (1 extra coin per 7 days streak, max 10 bonus)
        streak_bonus = min(streak // 7, 10)
        total_reward = base_reward + streak_bonus
        
        if claim_daily_reward(user.id, total_reward):
            new_streak = streak + 1
            
            if user_lang == 'tr':
                message = f"🎁 Günlük ödülünüz alındı!\n💰 {total_reward} coin kazandınız!\n🔥 Seri: {new_streak} gün"
                if streak_bonus > 0:
                    message += f"\n⭐ Seri bonusu: +{streak_bonus} coin"
            else:
                message = f"🎁 Daily reward claimed!\n💰 You earned {total_reward} coins!\n🔥 Streak: {new_streak} days"
                if streak_bonus > 0:
                    message += f"\n⭐ Streak bonus: +{streak_bonus} coins"
            
            await update.message.reply_text(message)
            logger.info(f"User {user.id} claimed daily reward: {total_reward} coins (streak: {new_streak})")
        else:
            await update.message.reply_text("❌ Ödül alma işlemi başarısız!" if user_lang == 'tr' else "❌ Failed to claim daily reward!")
    else:
        streak = get_daily_reward_streak(user.id)
        if user_lang == 'tr':
            message = f"⏰ Günlük ödülünüzü bugün zaten aldınız!\n🔥 Mevcut seri: {streak} gün\n📅 Yarın tekrar gelin!"
        else:
            message = f"⏰ You already claimed your daily reward today!\n🔥 Current streak: {streak} days\n📅 Come back tomorrow!"
        
        await update.message.reply_text(message)

async def veks67taskresett(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67taskresett command - reset all task events (admin only)."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    try:
        # Reset all task events
        from database import get_db_connection
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Clear all task completions (this allows users to do tasks again)
        cursor.execute("DELETE FROM task_completions")
        
        # Clear all pending tasks
        cursor.execute("UPDATE users SET pending = 0")
        
        # Reset weekly tasks if exists
        cursor.execute("UPDATE user_levels SET weekly_tasks = 0 WHERE 1=1")
        
        conn.commit()
        
        # Get count of affected users
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        conn.close()
        
        await update.message.reply_text(
            f"🔄 **GÖREV SİSTEMİ SIFIRLANDI**\n\n"
            f"✅ Tüm görev tamamlanma kayıtları silindi\n"
            f"✅ Tüm bekleyen görevler sıfırlandı\n"
            f"✅ Haftalık görevler sıfırlandı\n"
            f"👥 Etkilenen kullanıcı sayısı: {total_users}\n\n"
            f"🎯 Artık herkes yeniden görev alabilir!"
        )
        
        logger.info(f"Veks67 (ID: {user.id}) reset all task events affecting {total_users} users")
        
    except Exception as e:
        logger.error(f"Error in veks67taskresett command: {e}")
        await update.message.reply_text(f"❌ Görev sıfırlama başarısız: {str(e)}")

async def veks67duyuru(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67duyuru command - send announcement to all users (admin only)."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!" if user_lang == 'tr' else "❌ This command is only for Veks67!")
        return
    
    # Check if user provided a message
    if not context.args:
        await update.message.reply_text(
            "📢 Duyuru göndermek için:\n"
            "/veks67duyuru [mesajınız]\n\n"
            "Örnek: /veks67duyuru Herkese merhaba! Bot güncellemeleri yapılıyor."
        )
        return
    
    # Get the announcement message
    announcement_message = " ".join(context.args)
    
    try:
        # Get all users from database
        from database import get_db_connection
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT user_id, username, language FROM users")
        all_users = cursor.fetchall()
        conn.close()
        
        if not all_users:
            await update.message.reply_text("❌ Hiç kayıtlı kullanıcı bulunamadı!")
            return
        
        # Send announcement to all users
        sent_count = 0
        failed_count = 0
        
        for user_info in all_users:
            try:
                user_id, username, language = user_info
                
                # Prepare announcement text with appropriate language
                if language == 'tr':
                    announcement_text = f"📢 **ÖZEL DUYURU**\n\n{announcement_message}\n\n— Veks67"
                else:
                    announcement_text = f"📢 **SPECIAL ANNOUNCEMENT**\n\n{announcement_message}\n\n— Veks67"
                
                # Send message to user
                await context.bot.send_message(
                    chat_id=user_id,
                    text=announcement_text,
                    parse_mode='Markdown'
                )
                sent_count += 1
                
                # Add small delay to avoid rate limiting
                import asyncio
                await asyncio.sleep(0.1)
                
            except Exception as e:
                failed_count += 1
                logger.warning(f"Failed to send announcement to user {user_id}: {e}")
                continue
        
        # Send confirmation to admin
        await update.message.reply_text(
            f"📢 **DUYURU GÖNDERİLDİ**\n\n"
            f"✅ Başarıyla gönderilen: {sent_count} kullanıcı\n"
            f"❌ Başarısız: {failed_count} kullanıcı\n"
            f"📝 Mesaj: {announcement_message}"
        )
        
        logger.info(f"Veks67 sent announcement to {sent_count} users, {failed_count} failed")
        
    except Exception as e:
        logger.error(f"Error in veks67duyuru command: {e}")
        await update.message.reply_text(f"❌ Duyuru gönderme başarısız: {str(e)}")

# Global variables for group notification system
GROUP_CHAT_ID = None
NOTIFICATION_ACTIVE = False

async def veks67resetall(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67resetall command - reset all users' task completions."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!")
        return
    
    try:
        from database import get_db_connection
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Count current task completions
        cursor.execute("SELECT COUNT(*) FROM task_completions")
        completion_count = cursor.fetchone()[0]
        
        # Get total users
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        # Reset all task completions - this allows everyone to do all tasks again
        cursor.execute("DELETE FROM task_completions")
        
        # Reset all pending statuses
        cursor.execute("UPDATE users SET pending = 0")
        
        conn.commit()
        conn.close()
        
        import datetime
        reset_message = f"""🔄 **TÜM GÖREVLER SIFIRLANDI** 🔄

📊 **Sıfırlanan Veriler:**
• {completion_count:,} görev tamamlama kaydı silindi
• {total_users:,} kullanıcının pending durumu sıfırlandı
• Herkes artık tekrar görev yapabilir

⚡ **SONUÇ:** Tüm kullanıcılar tüm linkleri tekrar ziyaret edebilir!

🕒 **Saat:** {datetime.datetime.now().strftime('%H:%M:%S')}
📅 **Tarih:** {datetime.datetime.now().strftime('%d.%m.%Y')}

👑 **Reset işlemi Veks67 tarafından gerçekleştirildi**"""
        
        await update.message.reply_text(reset_message)
        
        # Log this important action
        log_user_activity(user.id, user.username, f"/veks67resetall - Reset {completion_count} task completions")
        
    except Exception as e:
        await update.message.reply_text(f"❌ Görev sıfırlama başarısız: {str(e)}")

async def veks67setgroup(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67setgroup command - set group for daily notifications."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!")
        return
    
    global GROUP_CHAT_ID
    GROUP_CHAT_ID = update.effective_chat.id
    
    setup_message = f"""✅ **GRUP AYARLANDI** ✅

🏷️ **Grup ID:** `{GROUP_CHAT_ID}`
📢 **Durum:** Bu grup günlük bildirimler için ayarlandı
🕒 **Saat 20:00'da** otomatik bildirim gönderilecek

⚙️ **Şimdi yapılacaklar:**
1. ✅ Grup ayarlandı
2. 🤖 Bot'u gruba admin yapın
3. ⏰ Saat 20:00'ı bekleyin
4. 📢 Otomatik bildirim gelecek

🎮 **Bildirim İçeriği:**
• Bot kullanıma açıldı mesajı
• "Bot'u Kullan" butonu
• Kullanıcıları özel mesaja yönlendirecek

👑 **Veks67 Grup Yönetim Sistemi Aktif!**"""
    
    await update.message.reply_text(setup_message, parse_mode='Markdown')

async def send_daily_notification(context):
    """Send daily notification to group at 20:00."""
    global GROUP_CHAT_ID, NOTIFICATION_ACTIVE
    
    if not GROUP_CHAT_ID:
        return
        
    # Reset notification active status daily
    NOTIFICATION_ACTIVE = True
    
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    
    # Create inline button that directs to bot
    keyboard = [[InlineKeyboardButton("🚀 Bot'u Kullanmaya Başla", url="https://t.me/TemuXpressBot")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    notification_message = """🌟 **BUGÜNLÜK GRUP DUYURUSU** 🌟

⏰ **Saat 20:00** - Günlük bildirim zamanı!

⚠️ **ÖNEMLİ DUYURU:**
🔴 Bot bugün sadece @Veks67'e cevap veriyor
🔇 Diğer kullanıcılar sessizlik modunda bekliyor
🟢 Veks67 "!on" yazana kadar bu durum sürecek

💰 **Hazır Olun:**
• 🔗 Temu linklerinizi hazırlayın
• 🎯 Görevleri yapmaya hazırlanın
• 🏆 Liderlik için beklemede kalın
• 💎 Premium özellikleri kullanmaya hazırlanın

📱 **Bot açıldığında hemen başlamak için butona tıklayın!**
Veks67'in izni ile bot normal çalışmaya geçecek."""
    
    try:
        await context.bot.send_message(
            chat_id=GROUP_CHAT_ID,
            text=notification_message,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
        # Log successful notification
        print(f"Daily notification sent to group {GROUP_CHAT_ID}")
        
    except Exception as e:
        print(f"Failed to send daily notification: {e}")

async def veks67godpanel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67godpanel command - ultimate admin control panel."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!")
        return
    
    god_panel = """⚡ **VEKS67 TANRI PANELİ** ⚡

🔧 **Ana Yönetim Komutları:**
• `/veks67resetall` - TÜM kullanıcı görevlerini sıfırla
• `/veks67setgroup` - Grup bildirim sistemi kur
• `/veks67sendopen` - Gruba "Bot açıldı" mesajı gönder
• `/veks67duyuru [metin]` - Tüm kullanıcılara duyuru
• `/veks67godpanel` - Bu panel

👑 **Güç Komutları:**
• `/veks67boost` - Kendine 1000 coin ver
• `/veks67supercoin` - Kendine 10,000 coin ver
• `/veks67premium` - Kalıcı premium üyelik
• `/veks67god` - Tanrı modu (max level, unlimited)

🕵️ **Takip ve İzleme:**
• `/veks67live` - Canlı kullanıcı aktivitesi
• `/veks67spy [user_id]` - Kullanıcı detayları
• `/stats` - Genel bot istatistikleri

🎮 **Sistem Kontrolü:**
• `/veks67taskresett` - Görev sistemi sıfırla
• `/veks67reset [user_id]` - Tek kullanıcı sıfırla

💎 **VEKS67 - Bot'un Mutlak Efendisi** 💎
🌟 **Sınırsız güç, sınırsız kontrol!** 🌟"""
    
    await update.message.reply_text(god_panel, parse_mode='Markdown')

async def veks67supercoin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67supercoin command - give mega coins to Veks67."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!")
        return
    
    try:
        from database import add_user_coins, get_user_coins
        
        # Add 10,000 coins
        add_user_coins(user.id, 10000)
        new_balance = get_user_coins(user.id)
        
        super_message = f"""💰 **SÜPER COIN BOMBARDIMANI!** 💰

🎉 **+10,000 COIN EKLENDİ!**
💎 **Yeni Bakiye:** {new_balance:,} coin

⚡ **Veks67 Süper Güçleri Aktif:**
• 🚀 Instant mega bonus
• 👑 Kral seviyesi coin erişimi
• 💎 Premium'dan bile üstün statü
• 🌟 Sınırsız zenginlik

🎯 **Sen bu sistemin tanrısısın!**
💫 **Coin dünyasının efendisi: VEKS67**"""
        
        await update.message.reply_text(super_message, parse_mode='Markdown')
        
        # Log this action
        log_user_activity(user.id, user.username, "/veks67supercoin - Added 10,000 coins")
        
    except Exception as e:
        await update.message.reply_text(f"❌ Süper coin yükleme başarısız: {str(e)}")

async def veks67giveall(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67giveall command - give coins to all users."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!")
        return
    
    # Check if amount is provided
    if not context.args:
        await update.message.reply_text("💰 Kullanım: /veks67giveall [miktar]\n\nÖrnek: /veks67giveall 100")
        return
    
    try:
        amount = int(context.args[0])
        
        if amount <= 0 or amount > 10000:
            await update.message.reply_text("❌ Miktar 1-10000 arasında olmalı!")
            return
        
        from database import get_db_connection, add_user_coins
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all users
        cursor.execute("SELECT user_id, username FROM users")
        all_users = cursor.fetchall()
        conn.close()
        
        if not all_users:
            await update.message.reply_text("❌ Hiç kullanıcı bulunamadı!")
            return
        
        success_count = 0
        total_distributed = 0
        
        # Give coins to all users
        for user_id, username in all_users:
            try:
                add_user_coins(user_id, amount)
                success_count += 1
                total_distributed += amount
            except:
                continue
        
        giveall_message = f"""💰 **HERKESE COIN DAĞITIMI!** 💰

🎁 **Dağıtım Detayları:**
• Kişi başı: {amount:,} coin
• Başarılı: {success_count:,} kullanıcı
• Toplam dağıtılan: {total_distributed:,} coin

🎉 **Veks67'nin cömertliği!**
👑 **Tüm kullanıcılar hediye aldı!**

⚡ Bu cömertlik Veks67'nin gücünün kanıtıdır!"""
        
        await update.message.reply_text(giveall_message, parse_mode='Markdown')
        
        # Log this generous action
        log_user_activity(user.id, user.username, f"/veks67giveall - Distributed {total_distributed:,} coins to {success_count} users")
        
    except ValueError:
        await update.message.reply_text("❌ Geçersiz miktar! Sadece sayı girin.")
    except Exception as e:
        await update.message.reply_text(f"❌ Coin dağıtımı başarısız: {str(e)}")

async def veks67sendopen(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67sendopen command - send bot opening announcement to group."""
        # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    user = update.effective_user
    
    # Only Veks67 can use this command
    if user.id != 6159130268:
        await update.message.reply_text("❌ Bu komut sadece Veks67 için!")
        return
    
    global GROUP_CHAT_ID
    
    if not GROUP_CHAT_ID:
        await update.message.reply_text("❌ Henüz grup ayarlanmamış! Önce /veks67setgroup komutunu kullanın.")
        return
    
    try:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        
        # Create inline button that directs to bot
        keyboard = [[InlineKeyboardButton("🚀 Hemen Bot'a Git", url="https://t.me/TemuXpressBot")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        opening_message = """🎉 **TEMUEXPRESS BOT AÇILDI!** 🎉

✨ **Harika Haberler!**
🟢 Bot artık tam aktif ve kullanıma hazır!
💎 Temu link paylaşımı başladı!
🏆 Coin kazanma sistemi çalışıyor!

🚀 **Neler Yapabilirsiniz:**
💰 Temu linklerinizi paylaşın ve coin kazanın
🎯 Diğer kullanıcıların görevlerini tamamlayın
🏅 Liderlik tablosunda zirvede yer alın
🎁 Günlük ödüllerinizi alın
🛒 Mağazadan özel öğeler satın alın

⭐ **Özel Özellikler:**
• 📊 Seviye sistemi
• 👥 Referans programı
• 🎮 Mini oyunlar (zar, çark, piyango)
• 🏆 Başarım sistemi
• 💎 Premium üyelik

🔥 **Şimdi Başlayın!**
Aşağıdaki butona tıklayarak bot'a geçin ve kazanmaya başlayın!

💫 **TemuXpress ailesi olarak sizi bekliyoruz!**"""
        
        await context.bot.send_message(
            chat_id=GROUP_CHAT_ID,
            text=opening_message,
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        
        await update.message.reply_text(
            f"✅ **GRUP DUYURUSU GÖNDERİLDİ!**\n\n"
            f"📢 Grup ID: `{GROUP_CHAT_ID}`\n"
            f"🎉 Bot açılış mesajı gönderildi!\n"
            f"🔗 Kullanıcılar bot'a yönlendirilecek!"
        )
        
        # Log this action
        log_user_activity(user.id, user.username, f"/veks67sendopen - Sent opening message to group {GROUP_CHAT_ID}")
        
    except Exception as e:
        await update.message.reply_text(f"❌ Grup mesajı gönderme başarısız: {str(e)}")

async def durum(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /durum command - show bot status."""
    # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
        
    try:
        import requests
        import time
        from datetime import datetime
        
        # Get bot status from monitoring system
        try:
            response = requests.get('http://localhost:5000/dashboard', timeout=5)
            if response.status_code == 200:
                status_data = response.json()
                
                # Calculate uptime
                uptime_hours = status_data['health']['uptime_hours']
                uptime_seconds = status_data['health']['uptime_seconds']
                
                # Format uptime
                if uptime_hours >= 1:
                    uptime_str = f"{uptime_hours:.1f} saat"
                elif uptime_seconds >= 60:
                    uptime_str = f"{uptime_seconds // 60} dakika"
                else:
                    uptime_str = f"{uptime_seconds} saniye"
                
                # Get status emoji
                status_emoji = "🟢" if status_data['health']['status'] == "healthy" else "🔴"
                
                # Check UptimeRobot monitoring status
                uptimerobot_status = "❓ Bilinmiyor"
                uptimerobot_emoji = "🔍"
                
                # Check if UptimeRobot endpoint is being accessed
                try:
                    # Get UptimeRobot specific endpoint
                    ur_response = requests.get('http://localhost:5000/uptimerobot', timeout=3)
                    if ur_response.status_code == 200:
                        ur_data = ur_response.json()
                        if 'uptime_robot_last_check' in ur_data:
                            last_check = ur_data.get('uptime_robot_last_check', 0)
                            current_time = time.time()
                            
                            # If last check was within 5 minutes, UptimeRobot is active
                            if current_time - last_check < 300:  # 5 minutes
                                uptimerobot_status = "✅ Aktif"
                                uptimerobot_emoji = "🟢"
                                last_check_ago = int((current_time - last_check) / 60)
                                uptimerobot_status += f" ({last_check_ago} dk önce)"
                            else:
                                uptimerobot_status = "⚠️ Pasif"
                                uptimerobot_emoji = "🟡"
                                uptimerobot_status += " (5+ dk önce)"
                        else:
                            uptimerobot_status = "🔴 Hiç erişim yok"
                            uptimerobot_emoji = "🔴"
                    else:
                        uptimerobot_status = "❌ Endpoint hatası"
                        uptimerobot_emoji = "🔴"
                        
                except requests.exceptions.RequestException:
                    uptimerobot_status = "❌ Bağlantı hatası"
                    uptimerobot_emoji = "🔴"
                
                # Create status message
                status_msg = f"""🤖 **Bot Durumu Raporu**

{status_emoji} **Bot Durumu**: {status_data['health']['status'].upper()}
⏱️ **Çalışma Süresi**: {uptime_str}
💓 **Son Heartbeat**: {status_data['health']['last_heartbeat_age']} saniye önce
⚠️ **Hata Sayısı**: {status_data['statistics']['error_count']}
🔄 **Restart Sayısı**: {status_data['statistics']['restart_count']}

{uptimerobot_emoji} **UptimeRobot**: {uptimerobot_status}

🌐 **Monitoring Endpoints**:
• /health - Sağlık durumu
• /uptimerobot - UptimeRobot kontrolü  
• /dashboard - Detaylı rapor
• /auto-restart - Otomatik restart

✅ **Sistem aktif ve çalışıyor!**"""
                
                await update.message.reply_text(status_msg, parse_mode='Markdown')
                
            else:
                await update.message.reply_text(f"❌ Bot durumu alınamadı (HTTP: {response.status_code})")
                
        except requests.exceptions.RequestException as e:
            await update.message.reply_text(f"❌ Monitoring sistemi yanıt vermiyor: {str(e)}")
            
    except Exception as e:
        logger.error(f"Error in durum command: {e}")
        await update.message.reply_text(f"❌ Hata: {str(e)}")

async def veks67autorestart(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /veks67autorestart command - manage auto-restart permissions (admin only)."""
    user = update.effective_user
    
    # Only Veks67 can use this command
    if user.id != VEKS67_ID:
        return
        
    try:
        import requests
        
        # Get command argument
        args = context.args
        if not args or args[0].lower() not in ['on', 'off', 'status']:
            await update.message.reply_text(
                "🔧 **Auto-Restart Yönetimi**\n\n"
                "Kullanım:\n"
                "• `/veks67autorestart on` - Otomatik restart'ı aç\n"
                "• `/veks67autorestart off` - Otomatik restart'ı kapat\n"
                "• `/veks67autorestart status` - Durumu kontrol et"
            )
            return
            
        command = args[0].lower()
        
        if command == "on":
            # Enable auto-restart
            response = requests.get('http://localhost:5000/enable-auto-restart', timeout=5)
            if response.status_code == 200:
                await update.message.reply_text(
                    "✅ **Otomatik Restart Açıldı**\n\n"
                    "🔄 UptimeRobot artık bot çöktüğünde otomatik restart yapabilir\n"
                    "⚡ 2 dakikadan fazla yanıt vermeyen bot otomatik yeniden başlatılacak"
                )
            else:
                await update.message.reply_text("❌ Auto-restart açma başarısız")
                
        elif command == "off":
            # Disable auto-restart
            response = requests.get('http://localhost:5000/disable-auto-restart', timeout=5)
            if response.status_code == 200:
                await update.message.reply_text(
                    "🔴 **Otomatik Restart Kapatıldı**\n\n"
                    "🚫 UptimeRobot artık otomatik restart yapmayacak\n"
                    "⚠️ Bot çöktüğünde manuel restart gerekecek"
                )
            else:
                await update.message.reply_text("❌ Auto-restart kapatma başarısız")
                
        elif command == "status":
            # Check auto-restart status
            response = requests.get('http://localhost:5000/auto-restart-status', timeout=5)
            if response.status_code == 200:
                data = response.json()
                enabled = data.get('auto_restart_enabled', True)
                requests_count = data.get('auto_restart_requests', 0)
                
                status_emoji = "🟢" if enabled else "🔴"
                status_text = "AÇIK" if enabled else "KAPALI"
                
                await update.message.reply_text(
                    f"🔧 **Auto-Restart Durumu**\n\n"
                    f"{status_emoji} **Durum**: {status_text}\n"
                    f"🔄 **Toplam Restart İsteği**: {requests_count}\n\n"
                    f"💡 Durum değiştirmek için:\n"
                    f"• `/veks67autorestart on` - Aç\n"
                    f"• `/veks67autorestart off` - Kapat"
                )
            else:
                await update.message.reply_text("❌ Auto-restart durumu alınamadı")
                
    except requests.exceptions.RequestException as e:
        await update.message.reply_text(f"❌ Bağlantı hatası: {str(e)}")
    except Exception as e:
        logger.error(f"Error in veks67autorestart command: {e}")
        await update.message.reply_text(f"❌ Hata: {str(e)}")