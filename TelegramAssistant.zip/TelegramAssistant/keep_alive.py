from flask import Flask, jsonify, make_response
from threading import Thread
import os
import time
import threading

# TemuXpress monitoring integration
temuXpress_monitoring = {
    "startup_time": time.time(),
    "total_checks": 0,
    "last_check": None,
    "health_score": 100,
    "consecutive_uptime": 0
}

# Import and initialize Guardian
try:
    from uptime_guardian import start_guardian, get_guardian_status, get_uptime_report
    guardian_available = True
    print("✅ Guardian system loaded successfully")
except ImportError as e:
    guardian_available = False
    start_guardian = lambda: None
    get_guardian_status = lambda: {"guardian_active": False}
    get_uptime_report = lambda: {"status": "UNAVAILABLE"}
    print(f"⚠️ Guardian system not available: {e}")

app = Flask('')

# Bot status tracking
bot_status = {
    "is_running": False,
    "last_heartbeat": None,
    "error_count": 0,
    "restart_count": 0,
    "start_time": time.time(),
    "uptime_robot_last_check": 0,
    "uptime_robot_check_count": 0,
    "auto_restart_enabled": True,  # Auto-restart permission
    "auto_restart_requests": 0     # Count of auto-restart attempts
}

# Thread-safe status updates
status_lock = threading.Lock()

def update_bot_status(is_running=None, error_occurred=False, restart_occurred=False):
    """Update bot status with thread safety."""
    with status_lock:
        if is_running is not None:
            bot_status["is_running"] = is_running
        if is_running:
            bot_status["last_heartbeat"] = time.time()
        if error_occurred:
            bot_status["error_count"] += 1
        if restart_occurred:
            bot_status["restart_count"] += 1

def get_bot_status():
    """Get current bot status with thread safety."""
    with status_lock:
        return bot_status.copy()

# CORS ve diğer header'ları düzelt
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    response.headers.add('Cache-Control', 'no-cache, no-store, must-revalidate')
    response.headers.add('Pragma', 'no-cache')
    response.headers.add('Expires', '0')
    return response

@app.route('/')
def home():
    # Keep-alive ping endpoint - prevents Replit sleep
    current_time = time.time()
    status = get_bot_status()
    uptime = current_time - status["start_time"] if status["start_time"] else 0
    
    keep_alive_message = f"""TemuXpress Bot - Always Alive!
⏰ Uptime: {int(uptime/3600)}h {int((uptime%3600)/60)}m
🤖 Status: {status['is_running'] and 'Running' or 'Stopped'}
🌐 Port: 8080
📡 Last ping: {time.strftime('%H:%M:%S')}
🔄 Restarts: {status['restart_count']}
📊 UptimeRobot pings: {status.get('uptime_robot_check_count', 0)}

This endpoint keeps the bot active 24/7!"""
    
    response = make_response(keep_alive_message, 200)
    response.headers['Content-Type'] = 'text/plain; charset=utf-8'
    return response

@app.route('/health')
def health():
    status = get_bot_status()
    current_time = time.time()
    uptime = current_time - status["start_time"]
    
    # Check if bot is healthy
    is_healthy = (
        status["is_running"] and 
        status["last_heartbeat"] and 
        (current_time - status["last_heartbeat"]) < 300  # 5 minutes
    )
    
    return jsonify({
        "status": "healthy" if is_healthy else "degraded",
        "service": "TemuXpress Bot",
        "timestamp": int(current_time),
        "uptime": int(uptime),
        "bot_running": status["is_running"],
        "last_heartbeat": status["last_heartbeat"],
        "error_count": status["error_count"],
        "restart_count": status["restart_count"]
    }), 200 if is_healthy else 503

@app.route('/ping')
def ping():
    response = make_response("pong", 200)
    response.headers['Content-Type'] = 'text/plain'
    return response

@app.route('/uptime')
def uptime():
    """TemuXpress 7/24 UptimeRobot endpoint with Guardian integration"""
    with status_lock:
        current_time = time.time()
        temuXpress_monitoring["last_check"] = current_time
        temuXpress_monitoring["total_checks"] += 1
        temuXpress_monitoring["consecutive_uptime"] += 1
        
        # Calculate health based on uptime
        uptime_hours = (current_time - temuXpress_monitoring["startup_time"]) / 3600
        temuXpress_monitoring["health_score"] = min(100, 90 + int(uptime_hours))
    
    # Get Guardian status if available
    guardian_status = "ACTIVE"
    if guardian_available:
        try:
            guardian_stats = get_guardian_status()
            guardian_status = "GUARDIAN_ACTIVE" if guardian_stats["guardian_active"] else "GUARDIAN_INACTIVE"
        except:
            guardian_status = "GUARDIAN_UNKNOWN"
    
    # Return enhanced response for UptimeRobot
    response_text = f"TemuXpress-ONLINE-{guardian_status}"
    response = make_response(response_text, 200)
    response.headers['X-Service'] = 'TemuXpress-Bot'
    response.headers['X-Health'] = str(temuXpress_monitoring["health_score"])
    response.headers['X-Guardian'] = guardian_status
    response.headers['X-Uptime-Hours'] = str(int(uptime_hours))
    response.headers['Content-Type'] = 'text/plain'
    return response

@app.route('/simple')
def simple():
    """TemuXpress simple status for UptimeRobot"""
    with status_lock:
        temuXpress_monitoring["total_checks"] += 1
        temuXpress_monitoring["last_check"] = time.time()
    
    bot_status_data = get_bot_status()
    is_running = bot_status_data["is_running"]
    
    # TemuXpress specific response
    if is_running:
        response_text = "TemuXpress-ACTIVE"
        status_code = 200
    else:
        response_text = "TemuXpress-DOWN"
        status_code = 503
    
    response = make_response(response_text, status_code)
    response.headers['X-TemuXpress'] = 'Telegram-Bot'
    response.headers['Content-Type'] = 'text/plain'
    return response

@app.route('/status')
def status():
    response = make_response("UP", 200)
    response.headers['Content-Type'] = 'text/plain'
    return response

@app.route('/alive')
def alive():
    response = make_response("1", 200)
    response.headers['Content-Type'] = 'text/plain'
    return response

@app.route('/uptimerobot')
def uptimerobot():
    """TemuXpress Bot UptimeRobot Özel Monitoring Endpoint"""
    # Track UptimeRobot access
    with status_lock:
        bot_status["uptime_robot_last_check"] = time.time()
        bot_status["uptime_robot_check_count"] += 1
    
    status = get_bot_status()
    current_time = time.time()
    
    # Check if bot is responding - more lenient timing for stable monitoring
    heartbeat_age = current_time - status["last_heartbeat"] if status["last_heartbeat"] else 999
    is_responding = (
        status["is_running"] and 
        status["last_heartbeat"] and 
        heartbeat_age < 180  # 3 minutes for accurate monitoring
    )
    
    # Calculate uptime statistics
    uptime_hours = int((current_time - status["start_time"]) / 3600)
    uptime_minutes = int(((current_time - status["start_time"]) % 3600) / 60)
    
    # Determine health status
    health_percentage = 100 if is_responding else 0
    if status["error_count"] > 0:
        health_percentage = max(0, 100 - (status["error_count"] * 10))
    
    if is_responding:
        response_data = {
            "status": "ACTIVE",
            "service": "TemuXpress Telegram Bot",
            "project": "Temu Link Sharing & Coin Reward System",
            "version": "v2.5.1",
            "bot_info": {
                "telegram_bot_active": status["is_running"],
                "api_responding": True,
                "database_connected": True,
                "web_server_port": 5000
            },
            "monitoring": {
                "heartbeat_age_seconds": int(heartbeat_age),
                "uptime_hours": uptime_hours,
                "uptime_minutes": uptime_minutes,
                "health_percentage": health_percentage,
                "error_count": status["error_count"],
                "restart_count": status["restart_count"],
                "auto_restart_enabled": status.get("auto_restart_enabled", True)
            },
            "uptimerobot": {
                "last_check": status["uptime_robot_last_check"],
                "total_checks": status["uptime_robot_check_count"],
                "endpoint_version": "TemuXpress-v2.5.1",
                "recommended_interval": "5 minutes"
            },
            "system": {
                "timestamp": current_time,
                "timezone": "UTC",
                "environment": "Replit Production"
            }
        }
        response = make_response(jsonify(response_data), 200)
        response.headers['X-Bot-Status'] = 'active'
        response.headers['X-Service'] = 'temuXpress-bot'
        response.headers['X-Health'] = str(health_percentage)
    else:
        response_data = {
            "status": "DOWN",
            "service": "TemuXpress Telegram Bot",
            "project": "Temu Link Sharing & Coin Reward System", 
            "version": "v2.5.1",
            "bot_info": {
                "telegram_bot_active": status["is_running"],
                "api_responding": False,
                "database_connected": False,
                "web_server_port": 5000
            },
            "monitoring": {
                "heartbeat_age_seconds": int(heartbeat_age),
                "uptime_hours": uptime_hours,
                "uptime_minutes": uptime_minutes,
                "health_percentage": 0,
                "error_count": status["error_count"],
                "restart_count": status["restart_count"],
                "auto_restart_enabled": status.get("auto_restart_enabled", True)
            },
            "uptimerobot": {
                "last_check": status["uptime_robot_last_check"],
                "total_checks": status["uptime_robot_check_count"],
                "endpoint_version": "TemuXpress-v2.5.1",
                "alert_reason": f"Bot heartbeat missing for {int(heartbeat_age)} seconds"
            },
            "system": {
                "timestamp": current_time,
                "timezone": "UTC",
                "environment": "Replit Production"
            }
        }
        response = make_response(jsonify(response_data), 503)
        response.headers['X-Bot-Status'] = 'down'
        response.headers['X-Service'] = 'temuXpress-bot'
        response.headers['X-Health'] = '0'
    
    response.headers['Content-Type'] = 'application/json'
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

@app.route('/monitor')
def monitor():
    return jsonify({
        "status": "online", 
        "service": "TemuXpress Bot Monitor",
        "timestamp": int(time.time())
    }), 200

@app.route('/uptimerobot/status')
def uptimerobot_status():
    """Basit UptimeRobot status endpoint - sadece durum bilgisi"""
    status = get_bot_status()
    current_time = time.time()
    heartbeat_age = current_time - status["last_heartbeat"] if status["last_heartbeat"] else 999
    is_healthy = status["is_running"] and heartbeat_age < 180
    
    return jsonify({
        "status": "UP" if is_healthy else "DOWN",
        "service": "TemuXpress",
        "health": "100%" if is_healthy else "0%",
        "timestamp": int(current_time)
    }), 200 if is_healthy else 503

@app.route('/temuXpress/info')
def temuXpress_info():
    """TemuXpress Bot detaylı bilgi endpoint'i"""
    from database import get_active_users_stats
    
    try:
        stats = get_active_users_stats()
        status = get_bot_status()
        current_time = time.time()
        
        return jsonify({
            "project": "TemuXpress - Temu Link & Coin Bot",
            "status": "OPERATIONAL",
            "features": {
                "telegram_bot": True,
                "coin_system": True,
                "task_system": True,
                "multilingual": True,
                "referral_system": True,
                "shop_system": True,
                "games": True,
                "admin_panel": True
            },
            "statistics": {
                "total_users": stats.get('total_users', 0),
                "active_users": stats.get('users_with_links', 0),
                "total_coins": stats.get('total_coins', 0),
                "task_completions": stats.get('total_completions', 0)
            },
            "uptime": {
                "bot_running": status["is_running"],
                "uptime_hours": int((current_time - status["start_time"]) / 3600),
                "restart_count": status["restart_count"]
            },
            "version": "v2.5.1-Production",
            "last_updated": "2025-07-05"
        }), 200
    except Exception as e:
        return jsonify({
            "project": "TemuXpress",
            "status": "PARTIAL",
            "error": "Database connection issue",
            "timestamp": int(time.time())
        }), 503

# Note: Additional monitoring endpoints already exist above - no duplicates needed

@app.route('/robots.txt')
def robots():
    response = make_response("User-agent: *\nAllow: /\n", 200)
    response.headers['Content-Type'] = 'text/plain'
    return response

@app.route('/favicon.ico')
def favicon():
    response = make_response("", 204)
    return response

@app.route('/healthcheck')
def healthcheck():
    status = get_bot_status()
    current_time = time.time()
    
    is_healthy = (
        status["is_running"] and 
        status["last_heartbeat"] and 
        (current_time - status["last_heartbeat"]) < 300
    )
    
    response = make_response("HEALTHY" if is_healthy else "UNHEALTHY", 200 if is_healthy else 503)
    response.headers['Content-Type'] = 'text/plain'
    return response

@app.route('/restart')
def restart():
    """Endpoint to trigger bot restart."""
    request_bot_restart()
    return jsonify({
        "status": "restart_requested",
        "message": "Bot restart has been requested",
        "timestamp": int(time.time())
    }), 200

@app.route('/auto-restart')
def auto_restart():
    """Endpoint for automatic restart when bot is down."""
    status = get_bot_status()
    current_time = time.time()
    
    # Check if auto-restart is enabled
    if not status.get("auto_restart_enabled", True):
        return jsonify({
            "status": "auto_restart_disabled",
            "message": "Automatic restart is disabled by user",
            "timestamp": int(current_time)
        }), 403
    
    # Check if bot has been down for more than 2 minutes
    if (not status["is_running"] or 
        (status["last_heartbeat"] and (current_time - status["last_heartbeat"]) > 120)):
        
        # Track auto-restart attempt
        with status_lock:
            bot_status["auto_restart_requests"] += 1
        
        request_bot_restart()
        return jsonify({
            "status": "auto_restart_triggered",
            "message": "Bot was down, automatic restart triggered",
            "timestamp": int(current_time),
            "downtime": int(current_time - (status["last_heartbeat"] or current_time)),
            "restart_attempts": status["auto_restart_requests"]
        }), 200
    else:
        return jsonify({
            "status": "bot_healthy",
            "message": "Bot is running normally",
            "timestamp": int(current_time)
        }), 200

@app.route('/enable-auto-restart')
def enable_auto_restart():
    """Enable automatic restart functionality."""
    with status_lock:
        bot_status["auto_restart_enabled"] = True
    
    return jsonify({
        "status": "auto_restart_enabled",
        "message": "Automatic restart has been enabled",
        "timestamp": int(time.time())
    }), 200

@app.route('/disable-auto-restart')
def disable_auto_restart():
    """Disable automatic restart functionality."""
    with status_lock:
        bot_status["auto_restart_enabled"] = False
    
    return jsonify({
        "status": "auto_restart_disabled",
        "message": "Automatic restart has been disabled",
        "timestamp": int(time.time())
    }), 200

@app.route('/auto-restart-status')
def auto_restart_status():
    """Check current auto-restart status."""
    status = get_bot_status()
    
    return jsonify({
        "auto_restart_enabled": status.get("auto_restart_enabled", True),
        "auto_restart_requests": status.get("auto_restart_requests", 0),
        "timestamp": int(time.time())
    }), 200

@app.route('/dashboard')
def dashboard():
    """Comprehensive bot dashboard."""
    status = get_bot_status()
    current_time = time.time()
    uptime = current_time - status["start_time"]
    
    # Calculate health metrics
    last_heartbeat_age = (current_time - status["last_heartbeat"]) if status["last_heartbeat"] else None
    is_healthy = status["is_running"] and last_heartbeat_age and last_heartbeat_age < 300
    
    return jsonify({
        "service": "TemuXpress Bot Monitoring Dashboard",
        "timestamp": int(current_time),
        "health": {
            "status": "healthy" if is_healthy else "unhealthy",
            "bot_running": status["is_running"],
            "uptime_seconds": int(uptime),
            "uptime_hours": round(uptime / 3600, 2),
            "last_heartbeat": status["last_heartbeat"],
            "last_heartbeat_age": int(last_heartbeat_age) if last_heartbeat_age else None
        },
        "statistics": {
            "error_count": status["error_count"],
            "restart_count": status["restart_count"],
            "start_time": status["start_time"]
        },
        "endpoints": {
            "health": "/health",
            "uptimerobot": "/uptimerobot",
            "restart": "/restart",
            "auto_restart": "/auto-restart",
            "dashboard": "/dashboard"
        }
    }), 200

def run():
    # Replit optimized port sequence - 5000 is standard for external access
    primary_port = int(os.environ.get('PORT', 5000))
    print(f"Starting TemuXpress web server on port {primary_port} for Replit/UptimeRobot monitoring")
    
    # Try port 5000 first for better Replit external access
    ports_to_try = [5000, 8080, 3000, 4000]
    
    for port in ports_to_try:
        try:
            print(f"Attempting to start on port {port}")
            update_bot_status()  # Initialize status tracking
            app.run(host='0.0.0.0', port=port, debug=False, threaded=True, use_reloader=False)
            break
        except OSError as e:
            if "Address already in use" in str(e):
                print(f"Port {port} is already in use, trying next port...")
                continue
            else:
                print(f"Port {port} error: {e}")
                continue
        except Exception as e:
            print(f"Web server error on port {port}: {e}")
            continue
    else:
        print("All ports failed, web server could not start")

# Global bot restart flag
restart_requested = False

def request_bot_restart():
    """Request bot restart from web interface."""
    global restart_requested
    restart_requested = True
    update_bot_status(restart_occurred=True)

def is_restart_requested():
    """Check if restart was requested."""
    global restart_requested
    return restart_requested

def reset_restart_flag():
    """Reset restart flag."""
    global restart_requested
    restart_requested = False

@app.route('/guardian')
def guardian_status():
    """TemuXpress Guardian 7/24 monitoring status"""
    if not guardian_available:
        return jsonify({
            "status": "GUARDIAN_UNAVAILABLE",
            "message": "Guardian system not loaded",
            "timestamp": time.time()
        }), 503
        
    try:
        guardian_stats = get_guardian_status()
        uptime_report = get_uptime_report()
        
        return jsonify({
            "status": "GUARDIAN_OPERATIONAL",
            "guardian": guardian_stats,
            "uptime_report": uptime_report,
            "temuXpress_monitoring": temuXpress_monitoring,
            "timestamp": time.time()
        }), 200
        
    except Exception as e:
        return jsonify({
            "status": "GUARDIAN_ERROR",
            "error": str(e),
            "timestamp": time.time()
        }), 500

def keep_alive():
    # Start Guardian for 7/24 monitoring
    if guardian_available:
        try:
            start_guardian()
            print("🔥 TemuXpress 7/24 Guardian initialized!")
        except Exception as e:
            print(f"Guardian initialization failed: {e}")
    
    t = Thread(target=run)
    t.daemon = True
    t.start()