import os
import logging
import asyncio
import time
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters
from telegram.error import NetworkError, TimedOut, RetryAfter
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from bot_handlers import (
    start, gonder, handle_text, coin, benimlinkim, 
    gorev, top, dil, handle_language_callback, gorevim, givecoin, veks67coin, gunluk, stats, durum,
    veks67special, veks67boost, veks67premium, veks67god, veks67reset, veks67live, veks67spy, log_user_activity, veks67taskresett, veks67duyuru,
    veks67resetall, veks67setgroup, veks67godpanel, veks67supercoin, veks67giveall, veks67sendopen, send_daily_notification, veks67autorestart
)
from new_handlers import (
    ref, refstat, apply_ref, level, achievements, profile, shop, handle_shop_callback,
    lottery, dice, wheel, weekly, help_command
)
from database import init_database
from keep_alive import keep_alive, update_bot_status, is_restart_requested, reset_restart_flag
from threading import Thread

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def error_handler(update, context):
    """Enhanced error handling with detailed logging and recovery."""
    error = context.error
    
    # Log the error with more detail
    if update:
        logger.error(f'Update {update.update_id} caused error: {error}')
        if update.effective_user:
            logger.error(f'User: {update.effective_user.id} (@{update.effective_user.username})')
        if update.message:
            logger.error(f'Message: {update.message.text}')
    else:
        logger.error(f'No update context, error: {error}')
    
    # Handle specific error types
    if isinstance(error, RetryAfter):
        logger.warning(f'Rate limited. Sleeping for {error.retry_after} seconds')
        await asyncio.sleep(error.retry_after)
    elif isinstance(error, (NetworkError, TimedOut)):
        logger.warning(f'Network error: {error}. Bot will continue running.')
    else:
        logger.error(f'Unexpected error: {error}', exc_info=True)

def main():
    """Main function to start the Telegram bot."""
    # Get bot token from environment variables
    TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

    if not TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN environment variable is not set!")
        print("Please set your Telegram bot token as an environment variable.")
        print("Get your token from @BotFather on Telegram.")
        update_bot_status(is_running=False, error_occurred=True)
        return

    # Initialize database
    init_database()
    
    # Start web server for 24/7 uptime monitoring
    keep_alive()
    
    # Update status - bot is starting
    update_bot_status(is_running=True)
    
    # Start heartbeat and monitoring thread
    def heartbeat_worker():
        while True:
            try:
                update_bot_status(is_running=True)
                
                # Check for restart request
                if is_restart_requested():
                    logger.info("Restart requested via web interface, stopping bot...")
                    reset_restart_flag()
                    update_bot_status(is_running=False, restart_occurred=True)
                    # This will cause the bot to exit the polling loop
                    raise KeyboardInterrupt("Restart requested")
                
                time.sleep(30)  # Check every 30 seconds
            except KeyboardInterrupt:
                raise  # Re-raise to trigger restart
            except Exception as e:
                logger.error(f"Heartbeat error: {e}")
                time.sleep(30)
    
    heartbeat_thread = Thread(target=heartbeat_worker, daemon=True)
    heartbeat_thread.start()

    # Create application
    application = Application.builder().token(TOKEN).build()

    # Add command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("gonder", gonder))
    application.add_handler(CommandHandler("coin", coin))
    application.add_handler(CommandHandler("gorev", gorev))
    application.add_handler(CommandHandler("gorevim", gorevim))
    application.add_handler(CommandHandler("benimlinkim", benimlinkim))
    application.add_handler(CommandHandler("top", top))
    application.add_handler(CommandHandler("dil", dil))
    application.add_handler(CommandHandler("givecoin", givecoin))
    application.add_handler(CommandHandler("veks67coin", veks67coin))
    application.add_handler(CommandHandler("gunluk", gunluk))
    application.add_handler(CommandHandler("stats", stats))
    application.add_handler(CommandHandler("durum", durum))
    
    # Veks67 special admin commands
    application.add_handler(CommandHandler("veks67special", veks67special))
    application.add_handler(CommandHandler("veks67boost", veks67boost))
    application.add_handler(CommandHandler("veks67premium", veks67premium))
    application.add_handler(CommandHandler("veks67god", veks67god))
    application.add_handler(CommandHandler("veks67reset", veks67reset))
    application.add_handler(CommandHandler("veks67live", veks67live))
    application.add_handler(CommandHandler("veks67spy", veks67spy))
    application.add_handler(CommandHandler("veks67taskresett", veks67taskresett))
    application.add_handler(CommandHandler("veks67duyuru", veks67duyuru))
    
    # New Veks67 ultimate commands
    application.add_handler(CommandHandler("veks67resetall", veks67resetall))
    application.add_handler(CommandHandler("veks67setgroup", veks67setgroup))
    application.add_handler(CommandHandler("veks67godpanel", veks67godpanel))
    application.add_handler(CommandHandler("veks67supercoin", veks67supercoin))
    application.add_handler(CommandHandler("veks67giveall", veks67giveall))
    application.add_handler(CommandHandler("veks67sendopen", veks67sendopen))
    application.add_handler(CommandHandler("veks67autorestart", veks67autorestart))
    
    # New feature handlers
    application.add_handler(CommandHandler("ref", ref))
    application.add_handler(CommandHandler("refstat", refstat))
    application.add_handler(CommandHandler("refkod", apply_ref))
    application.add_handler(CommandHandler("level", level))
    application.add_handler(CommandHandler("achievements", achievements))
    application.add_handler(CommandHandler("profile", profile))
    application.add_handler(CommandHandler("shop", shop))
    application.add_handler(CommandHandler("lottery", lottery))
    application.add_handler(CommandHandler("dice", dice))
    application.add_handler(CommandHandler("wheel", wheel))
    application.add_handler(CommandHandler("weekly", weekly))
    application.add_handler(CommandHandler("help", help_command))

    # Add callback query handler for language selection
    application.add_handler(CallbackQueryHandler(handle_language_callback, pattern="^lang_"))
    
    # Add callback query handler for shop purchases
    application.add_handler(CallbackQueryHandler(handle_shop_callback, pattern="^shop_"))

    # Add text message handler (for link submission and task completion)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    # Add error handler
    application.add_error_handler(error_handler)

    # Note: Scheduler will be started after bot initialization

    # Start the bot with auto-restart on crash
    logger.info("Starting TemuXpress Bot...")
    
    retry_count = 0
    max_retries = 10
    base_delay = 5
    
    while retry_count < max_retries:
        try:
            update_bot_status(is_running=True)
            application.run_polling(drop_pending_updates=True)
            break  # If we get here, bot stopped gracefully
        except KeyboardInterrupt:
            logger.info("Bot stopped by user (Ctrl+C)")
            update_bot_status(is_running=False)
            break
        except Exception as e:
            retry_count += 1
            delay = base_delay * (2 ** (retry_count - 1))  # Exponential backoff
            
            logger.error(f"Bot crashed with error: {e}")
            logger.error(f"Retry attempt {retry_count}/{max_retries}")
            update_bot_status(is_running=False, error_occurred=True)
            
            if retry_count < max_retries:
                logger.info(f"Restarting bot in {delay} seconds...")
                update_bot_status(restart_occurred=True)
                time.sleep(delay)
            else:
                logger.error("Max retries reached. Bot will not restart automatically.")
                update_bot_status(is_running=False, error_occurred=True)
                raise

def run_bot_with_restart():
    """Run bot with automatic restart capability."""
    restart_count = 0
    max_global_restarts = 50
    
    while restart_count < max_global_restarts:
        try:
            logger.info("Initializing TemuXpress Bot...")
            update_bot_status(is_running=False, restart_occurred=True)
            main()
            logger.info("Bot stopped normally")
            break
        except KeyboardInterrupt:
            logger.info("Bot shutdown requested")
            update_bot_status(is_running=False)
            break
        except Exception as e:
            restart_count += 1
            delay = min(10 * restart_count, 300)  # Max 5 minutes delay
            
            logger.error(f"Critical error in bot initialization: {e}")
            logger.info(f"Global restart {restart_count}/{max_global_restarts} in {delay} seconds...")
            update_bot_status(is_running=False, error_occurred=True, restart_occurred=True)
            
            time.sleep(delay)
            
            if restart_count >= max_global_restarts:
                logger.error("Max global restarts reached. Bot will stop.")
                update_bot_status(is_running=False, error_occurred=True)
                break

if __name__ == "__main__":
    run_bot_with_restart()