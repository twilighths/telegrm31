"""
TemuXpress UptimeRobot Monitoring Integration
Specialized monitoring endpoints for 24/7 uptime tracking
"""

import time
import json
import threading
from flask import jsonify, make_response

# TemuXpress monitoring variables
temuXpress_stats = {
    "startup_time": time.time(),
    "total_uptime_checks": 0,
    "last_uptime_check": None,
    "monitoring_active": False,
    "consecutive_checks": 0,
    "health_score": 100
}

temuXpress_lock = threading.Lock()

def update_temuXpress_stats():
    """Update TemuXpress monitoring statistics"""
    with temuXpress_lock:
        current_time = time.time()
        temuXpress_stats["last_uptime_check"] = current_time
        temuXpress_stats["total_uptime_checks"] += 1
        temuXpress_stats["consecutive_checks"] += 1
        temuXpress_stats["monitoring_active"] = True
        
        # Calculate health score based on uptime
        uptime_hours = (current_time - temuXpress_stats["startup_time"]) / 3600
        if uptime_hours > 24:
            temuXpress_stats["health_score"] = min(100, 95 + (uptime_hours / 24))
        else:
            temuXpress_stats["health_score"] = max(90, 70 + (uptime_hours * 2))

def get_temuXpress_status():
    """Get comprehensive TemuXpress bot status for UptimeRobot"""
    with temuXpress_lock:
        current_time = time.time()
        uptime_seconds = current_time - temuXpress_stats["startup_time"]
        
        return {
            "project": "TemuXpress - Temu Link Sharing Bot",
            "status": "ONLINE",
            "health_percentage": temuXpress_stats["health_score"],
            "uptime": {
                "hours": int(uptime_seconds / 3600),
                "minutes": int((uptime_seconds % 3600) / 60),
                "total_seconds": int(uptime_seconds)
            },
            "monitoring": {
                "total_checks": temuXpress_stats["total_uptime_checks"],
                "consecutive_checks": temuXpress_stats["consecutive_checks"],
                "last_check": temuXpress_stats["last_uptime_check"],
                "monitoring_active": temuXpress_stats["monitoring_active"]
            },
            "features": {
                "telegram_bot": True,
                "coin_system": True,
                "task_rewards": True,
                "multilingual": True,
                "24_7_uptime": True
            },
            "technical": {
                "platform": "Replit",
                "port": 8080,
                "environment": "Production",
                "auto_restart": True
            }
        }

def create_temuXpress_uptime_response():
    """Create optimized UptimeRobot response for TemuXpress"""
    update_temuXpress_stats()
    
    # Simple response for UptimeRobot
    response_text = "TemuXpress-ONLINE"
    
    response = make_response(response_text, 200)
    response.headers['Content-Type'] = 'text/plain'
    response.headers['X-TemuXpress-Status'] = 'ACTIVE'
    response.headers['X-Bot-Health'] = str(temuXpress_stats["health_score"])
    response.headers['Cache-Control'] = 'no-cache'
    
    return response

def create_temuXpress_detailed_response():
    """Create detailed TemuXpress status for monitoring"""
    update_temuXpress_stats()
    status_data = get_temuXpress_status()
    
    response = make_response(jsonify(status_data), 200)
    response.headers['X-TemuXpress-Service'] = 'Telegram-Bot'
    response.headers['X-TemuXpress-Version'] = 'v2.5.1'
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    
    return response

def get_temuXpress_simple_status():
    """Get simple online/offline status"""
    update_temuXpress_stats()
    
    # Check if monitoring is active (last check within 10 minutes)
    if temuXpress_stats["last_uptime_check"]:
        time_since_check = time.time() - temuXpress_stats["last_uptime_check"]
        if time_since_check < 600:  # 10 minutes
            return "ONLINE"
    
    return "ONLINE"  # Default to online for new instances