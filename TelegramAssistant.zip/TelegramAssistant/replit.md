# TemuXpress Telegram Bot

## Overview

TemuXpress is a multilingual Telegram bot built in Python that facilitates link sharing and task completion with a coin-based reward system. The bot supports both Turkish and English languages with comprehensive user onboarding. Users can submit Temu links, complete tasks, and earn coins through various activities. The bot features language selection, detailed introduction system, leaderboard functionality, and provides multiple commands for user interaction.

## System Architecture

### Backend Architecture
- **Language**: Python 3
- **Framework**: python-telegram-bot library
- **Database**: SQLite with thread-safe connections
- **Architecture Pattern**: Command-based handlers with modular separation

### Key Design Decisions
- **SQLite Choice**: Chosen for simplicity and file-based storage, suitable for small to medium-scale deployments
- **Thread-safe Database**: Implemented thread-local storage to handle concurrent database access safely
- **Modular Handler Design**: Separated bot handlers from database operations for better maintainability
- **Environment-based Configuration**: Bot token configured via environment variables for security

## Key Components

### 1. Bot Handlers (`bot_handlers.py`)
- **Purpose**: Handles all Telegram bot commands and user interactions
- **Key Functions**:
  - `/start`: User registration and welcome message
  - `/gönder`: Link submission initiation
  - Text handling: Processes links and task completion ("bitti" command)
  - Additional commands: `/coin`, `/görev`, `/benimlinkim`, `/top`

### 2. Database Layer (`database.py`)
- **Purpose**: Manages all database operations with thread-safe connections
- **Key Features**:
  - Thread-local database connections
  - User registration and management
  - Coin tracking and transactions
  - Link storage and validation
  - Leaderboard functionality

### 3. Main Application (`main.py`)
- **Purpose**: Application entry point and bot configuration
- **Responsibilities**:
  - Bot token management
  - Database initialization
  - Handler registration
  - Error handling setup

## Data Flow

1. **User Registration**: Users start with `/start` command → Registration in database → Welcome message sent
2. **Link Submission**: `/gönder` command → User prompted → Link validated and stored
3. **Task System**: Users request tasks → Assigned pending status → Complete with "bitti" → Earn coins
4. **Coin Management**: Various actions trigger coin additions/subtractions → Database updated → User notified

## Database Schema

### Users Table
```sql
CREATE TABLE users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    link TEXT,
    coin INTEGER DEFAULT 0,
    pending INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

### Indexes
- `idx_users_coin`: Optimizes leaderboard queries
- `idx_users_pending`: Optimizes pending user lookups

## External Dependencies

### Core Dependencies
- **python-telegram-bot**: Telegram Bot API wrapper
- **sqlite3**: Built-in Python SQLite interface (no external dependency)
- **threading**: Built-in Python threading support
- **logging**: Built-in Python logging framework

### Environment Variables
- `TELEGRAM_BOT_TOKEN`: Bot authentication token (required)

## Deployment Strategy

### Current Setup
- **Platform**: Designed for Replit deployment
- **Database**: Local SQLite file (`temujoin.db`)
- **Configuration**: Environment variable for bot token
- **Logging**: Console-based logging with INFO level

### Deployment Requirements
1. Set `TELEGRAM_BOT_TOKEN` environment variable
2. Ensure Python 3.x runtime
3. Install python-telegram-bot library
4. Run `main.py` to start the bot

### Scalability Considerations
- SQLite suitable for moderate usage
- Thread-safe implementation handles concurrent users
- Modular design allows easy feature additions

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

✓ July 02, 2025 - Initial setup completed
✓ July 02, 2025 - Updated to python-telegram-bot v20.7 with async handlers  
✓ July 02, 2025 - Fixed command names (gönder → gonder, görev → gorev) for compatibility
✓ July 02, 2025 - Added Turkish/English language selection with inline keyboards
✓ July 02, 2025 - Implemented comprehensive introduction system for new users
✓ July 02, 2025 - Added translations.py module for multi-language support
✓ July 02, 2025 - Database migration completed - added language column
✓ July 02, 2025 - Bot deployed with full language features and working on real Telegram
✓ July 02, 2025 - Implemented task completion tracking to prevent duplicate tasks
✓ July 02, 2025 - Added task_completions table with user-target relationship tracking
✓ July 02, 2025 - Users can now only complete each link owner's task once, preventing abuse
✓ July 03, 2025 - Enhanced task assignment messages with clearer Temu link clicking instructions
✓ July 03, 2025 - Updated both Turkish and English translations for better user experience
✓ July 03, 2025 - Improved link presentation in task assignments and current task display
✓ July 03, 2025 - Implemented link visit verification system with "I Visited" button
✓ July 03, 2025 - Added protection against task completion without actually visiting links
✓ July 03, 2025 - Users must now click "Ziyaret Ettim" button before completing tasks with "bitti"
✓ July 03, 2025 - Added comprehensive bot statistics system with /stats command (admin only)
✓ July 03, 2025 - Statistics include user counts, coin distribution, task completions, and activity rates
✓ July 03, 2025 - **MAJOR UPDATE**: Complete feature expansion with all requested systems:

## 🚀 **New Features Added:**

### **1. Referral System**
- `/ref` - Get your referral code
- `/refstat` - View referral statistics
- `/refkod [CODE]` - Apply referral code
- 20 coins for referrer, 10 coins for new user

### **2. Level & Experience System**
- `/level` - View level information
- 10 levels: Bronze to Champion
- XP gained from task completion
- Automatic level up notifications

### **3. Achievement System**
- `/achievements` - View earned badges
- 9 different achievements to unlock
- Automatic award notifications
- Progress tracking for coins, tasks, referrals

### **4. User Profiles**
- `/profile` - Complete user profile
- Shows level, achievements, referrals
- Premium status display
- Custom titles from shop

### **5. Coin Shop**
- `/shop` - Purchase items with coins
- VIP/PRO/STAR titles (100-200 coins)
- Premium memberships (500-1500 coins)
- Auto-task features (300 coins)

### **6. Games & Gambling**
- `/dice [amount]` - Dice game vs bot
- `/wheel` - Spin fortune wheel
- `/lottery` - Buy lottery tickets (50 coins)
- Chance-based coin rewards

### **7. Enhanced Leaderboards**
- `/weekly` - Weekly task leaderboard
- Auto-reset system
- Medal rankings

### **8. Help System**
- `/help` - Complete command reference
- Categorized by feature type
- Turkish/English support

## **Database Enhancements:**
- New tables: referrals, achievements, user_levels, lottery_entries, shop_purchases
- Enhanced users table with premium status, titles, auto-task settings
- Thread-safe operations for all new features

## Changelog

Changelog:
- July 02, 2025. Initial setup
- July 02, 2025. Migrated to modern python-telegram-bot v20 API with async support
- July 02, 2025. Implemented proper event loop handling for Replit environment
- July 02, 2025. Bot deployed and running successfully
- July 03, 2025. Fixed critical shop system database transaction issues
- July 03, 2025. Resolved coin deduction problems in purchase system
- July 03, 2025. Added comprehensive Turkish translations for all new features
- July 03, 2025. Bot fully operational with all systems working correctly
- July 03, 2025. Added task reset system (/veks67taskresett) - allows admin to reset all task completions
- July 03, 2025. Added announcement system (/veks67duyuru) - allows admin to send messages to all users
- July 03, 2025. Simplified task system - removed "I Visited" button, users now only need to click link and type "bitti"
- July 03, 2025. Added link click verification - users must wait 10 seconds after getting task before completing with "bitti"
- July 03, 2025. Enhanced user identification - added User ID and username display in task assignments and leaderboard
- July 03, 2025. Added Flask web server (`keep_alive.py`) for 24/7 uptime monitoring via Uptime Robot
- July 04, 2025. **MAJOR VEKS67 ADMIN EXPANSION** - Added ultimate admin features for Veks67:

## 🚀 **New Veks67 Ultimate Features:**

### **1. Task Reset System**
- `/veks67resetall` - Reset ALL users' task completions (allows everyone to redo all tasks)
- Complete task completion database wipe
- Automatic pending status reset for all users

### **2. Group Notification System** 
- `/veks67setgroup` - Set group for daily 20:00 notifications
- Automatic daily scheduler system
- Group notification with "Start Bot" button
- Users redirected to private message

### **3. Ultimate Admin Panel**
- `/veks67godpanel` - Complete admin control center
- `/veks67supercoin` - Give 10,000 coins to Veks67
- `/veks67giveall [amount]` - Distribute coins to ALL users
- Enhanced power management system

### **4. Enhanced Error Handling**
- Robust auto-restart system with exponential backoff
- Network error recovery and rate limit handling
- Thread-safe database operations
- Detailed error logging with user context

### **5. UptimeRobot Integration**
- Fixed "repl unreachable" errors
- Port 8080 configuration for proper Replit proxy
- Multiple health check endpoints (/health, /ping, /uptimerobot)
- HTTPS support with proper headers

### **6. Daily Notification Scheduler**
- Automatic 20:00 (8 PM) daily group notifications
- APScheduler integration with cron triggers
- Group messaging with inline "Start Bot" buttons
- User redirection to private bot conversations

## **Technical Improvements:**
- Enhanced web server with CORS headers and cache control
- Thread-safe Flask implementation with daemon threads
- Improved error handling with specific exception types
- Automatic port configuration for Replit environment
- Advanced logging system for admin monitoring

## **Database Enhancements:**
- Task completion reset capabilities
- Global user management for coin distribution
- Enhanced admin logging and activity tracking
- Optimized queries for mass operations

## **Latest Major Update - July 05, 2025: UptimeRobot Auto-Recovery System**

### **Advanced Monitoring & Recovery System:**
- **Real-time Bot Status Tracking**: Thread-safe status monitoring with heartbeat system
- **Intelligent Health Checks**: Multi-endpoint health monitoring (/health, /uptimerobot, /healthcheck)
- **Auto-Restart Mechanism**: Web-triggered restart system with /restart and /auto-restart endpoints
- **Comprehensive Dashboard**: /dashboard endpoint with detailed bot statistics and health metrics
- **UptimeRobot Integration**: Optimized for UptimeRobot monitoring with proper HTTP status codes
- **Port Fallback System**: Automatic port selection (5000 → 8080 → 3000 → 4000) for maximum availability

### **Enhanced Error Recovery:**
- **Exponential Backoff**: Smart retry mechanism with increasing delays
- **Global Restart Tracking**: Up to 50 automatic restarts with intelligent delay scaling
- **Heartbeat Monitoring**: 30-second heartbeat system for real-time status updates
- **Status Persistence**: Thread-safe bot status tracking across restarts
- **Down Detection**: Automatic detection when bot is unresponsive for 2+ minutes

### **Technical Improvements:**
- **Thread-Safe Operations**: All status updates use threading locks
- **Background Monitoring**: Daemon threads for continuous health monitoring
- **Error Classification**: Specific handling for network errors, rate limits, and critical failures
- **Graceful Shutdowns**: Proper cleanup on restart requests and interruptions
- **Multi-Port Support**: Fallback port system for maximum UptimeRobot compatibility

## **Latest Update - July 05, 2025: Enhanced UptimeRobot Monitoring & Auto-Restart Control**

### **UptimeRobot Activity Tracking:**
- **Real-time Monitoring Detection**: Bot now tracks when UptimeRobot accesses monitoring endpoints
- **Activity Status Display**: `/durum` command shows UptimeRobot monitoring status (Active/Passive/Never accessed)
- **Access Timestamp Tracking**: Records last UptimeRobot check time and total access count
- **Smart Status Detection**: Automatically determines if UptimeRobot is actively monitoring (within 5 minutes)

### **Auto-Restart Permission System:**
- **Telegram Control**: New `/veks67autorestart` command for enabling/disabling auto-restart functionality
- **Permission Management**: Users can now control when UptimeRobot is allowed to automatically restart the bot
- **Status Monitoring**: Real-time tracking of auto-restart permissions and attempt counts
- **Web API Integration**: Auto-restart endpoint now checks permissions before triggering restarts

### **Enhanced Status Command (`/durum`):**
- **Comprehensive Bot Health**: Shows bot status, uptime, heartbeat, errors, and restart count
- **UptimeRobot Integration**: Displays real-time UptimeRobot monitoring activity
- **Auto-Restart Status**: Shows current auto-restart permission status and attempt counts
- **Visual Status Indicators**: Color-coded emojis for quick status assessment
- **Bilingual Support**: Full Turkish and English language support
- **Updated Help Menus**: Added to both Turkish and English command lists

### **New Commands:**
- **`/veks67autorestart on`**: Enable automatic restart functionality
- **`/veks67autorestart off`**: Disable automatic restart functionality
- **`/veks67autorestart status`**: Check current auto-restart status and statistics

### **Technical Improvements:**
- **Enhanced Endpoint Tracking**: `/uptimerobot` endpoint now logs access times and counts
- **JSON Response Format**: UptimeRobot endpoint returns structured data for better monitoring
- **Thread-Safe Operations**: All status updates use proper locking mechanisms
- **User-Friendly Display**: Status times formatted in Turkish (saat/dakika/saniye)
- **Permission-Based Auto-Restart**: `/auto-restart` endpoint now respects user-configured permissions

## **Latest Update - July 05, 2025: Enhanced UptimeRobot Monitoring System**

### **Advanced UptimeRobot Integration:**
- **Custom TemuXpress Endpoint**: Specialized `/uptimerobot` endpoint with project-specific monitoring
- **Multiple Monitoring Options**: 3 different endpoints for various monitoring needs
- **Enhanced JSON Response**: Detailed bot status, health percentage, uptime tracking
- **Real-time Statistics**: Live user counts, coin totals, task completions from database
- **Professional Headers**: Custom HTTP headers for better UptimeRobot integration

### **New Monitoring Endpoints:**
- **`/uptimerobot`**: Main detailed monitoring endpoint with full bot status
- **`/uptimerobot/status`**: Simple UP/DOWN status for basic monitoring
- **`/temuXpress/info`**: Project information with live statistics and features

### **Technical Improvements:**
- **Health Percentage Calculation**: Dynamic health based on errors and heartbeat
- **Uptime Hours/Minutes Display**: Human-readable uptime formatting
- **Cache Prevention Headers**: Ensures fresh data for monitoring services
- **Custom Service Headers**: X-Bot-Status, X-Service, X-Health for advanced monitoring
- **Error Resilience**: Graceful degradation when database issues occur

### **Monitoring Features:**
- **Heartbeat Tracking**: 3-minute tolerance for accurate status detection
- **Auto-restart Integration**: Seamless integration with existing auto-restart system
- **Version Information**: v2.5.1-Production tracking with endpoint versioning
- **Environment Detection**: Replit Production environment identification

## **Latest Update - July 05, 2025: TemuXpress Guardian 7/24 Monitoring System**

### **Advanced 7/24 UptimeRobot Guardian System:**
- **Guardian Integration**: Advanced monitoring system with auto-recovery capabilities
- **7/24 Self-Monitoring**: 30-second interval health checks with failure detection
- **Auto-Recovery**: Automatic restart attempts after 3 consecutive failures
- **Daily Statistics**: Tracks uptime percentage, check counts, and failure rates
- **Real-time Monitoring**: Continuous background monitoring with detailed logging

### **Guardian Features:**
- **Intelligent Health Checks**: Tests multiple endpoints (/uptime, /simple, /ping)
- **Failure Recovery**: Automatic restart via web endpoint after consecutive failures
- **Statistics Tracking**: Daily uptime percentage, consecutive success tracking
- **Thread-Safe Operations**: Proper locking for concurrent access
- **Performance Monitoring**: Tracks Guardian health, check intervals, and response times

### **Enhanced UptimeRobot URLs (Port 8080):**
1. **Guardian Uptime**: `https://[domain]:8080/uptime` - Returns "TemuXpress-ONLINE-GUARDIAN_ACTIVE"
2. **Simple Status**: `https://[domain]:8080/simple` - Returns "TemuXpress-ACTIVE"/"TemuXpress-DOWN"
3. **Ping Test**: `https://[domain]:8080/ping` - Returns "pong"
4. **Guardian Dashboard**: `https://[domain]:8080/guardian` - Detailed Guardian statistics

### **Guardian System Benefits:**
- **Proactive Monitoring**: Detects issues before UptimeRobot notices
- **Self-Healing**: Attempts automatic recovery without manual intervention
- **Comprehensive Logging**: Detailed statistics for uptime analysis
- **Multiple Redundancy**: Tests multiple endpoints for reliability
- **Performance Tracking**: Real-time health scoring and uptime percentage

### **Technical Implementation:**
- **Background Thread**: Daemon thread runs continuously for monitoring
- **HTTP Health Checks**: Regular endpoint testing with timeout handling
- **Failure Escalation**: Progressive response to consecutive failures
- **Statistics Persistence**: Daily stats tracking with automatic reset
- **Integration**: Seamless integration with existing keep-alive system