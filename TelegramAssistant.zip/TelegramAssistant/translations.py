"""
Language translations for the TemuJoin Telegram bot.
Supports Turkish and English languages.
"""

LANGUAGES = {
    'tr': {
        'welcome_title': "👋 TemuXpress'e Hoş Geldin!",
        'welcome_intro': (
            "🎯 Bu sistem Temu linklerini paylaşmak ve coin kazanmak için tasarlandı.\n\n"
            "📖 Nasıl Çalışır:\n"
            "• Kendi Temu linkini ekle\n"
            "• Diğer kullanıcıların linklerini ziyaret et\n"
            "• Her tamamlanan görev için coin kazan\n"
            "• Liderlik tablosunda yüksel!\n\n"
            "🎮 Başlamak için dil seçimini yap:"
        ),
        'language_selected': "🇹🇷 Türkçe seçildi! Şimdi komutları kullanabilirsin:",
        'commands_menu': (
            "📋 Komutlar:\n"
            "🔗 /gonder - Link ekle\n"
            "💼 /gorev - Görev al\n"
            "💰 /coin - Coin durumu\n"
            "🎁 /gunluk - Günlük ödül\n"
            "📋 /benimlinkim - Linkimi gör\n"
            "🏆 /top - Liderlik tablosu\n"
            "🤖 /durum - Bot durumu\n"
            "🌐 /dil - Dil değiştir\n"
            "❓ /help - Tüm komutları gör"
        ),
        'send_link_prompt': (
            "📎 Lütfen Temu linkini gönder:\n\n"
            "ℹ️ Link 'temu.com' içermelidir."
        ),
        'link_saved': (
            "✅ Link başarıyla kaydedildi!\n\n"
            "💡 Artık /gorev komutu ile görev alabilirsin."
        ),
        'invalid_link': (
            "❌ Bu geçerli bir Temu linki değil.\n\n"
            "🔍 Link 'temu.com' içermelidir."
        ),
        'task_completed': "✅ Görev tamamlandı! 1 coin kazandın. 🎉",
        'task_error': "❌ Görev tamamlanırken bir hata oluştu.",
        'no_active_task': "❌ Üzerinde aktif görev yok.",
        'coin_count': "💰 Coinin: {}",
        'your_link': "🔗 Kayıtlı linkin:\n{}",
        'no_link_saved': (
            "❌ Henüz link eklemedin.\n\n"
            "📎 /gonder komutunu kullanarak link ekleyebilirsin."
        ),
        'need_link_first': (
            "❌ Önce kendi linkini eklemelisin.\n\n"
            "📎 /gonder komutunu kullan."
        ),
        'already_has_task': (
            "🔁 Zaten aktif görevin var.\n\n"
            "✅ Görevini tamamladıysan 'bitti' yazmayı unutma."
        ),
        'no_tasks_available': (
            "⏳ Şu anlık görev verilecek kimse yok.\n\n"
            "💡 Biraz sonra tekrar dene ya da henüz tamamlamadığın linkler yoksa daha fazla coin kazanılması gerekebilir."
        ),
        'task_assigned': (
            "📩 Görevin:\n{}\n\n"
            "🔗 Yukarıdaki linke tıklayıp Temu sayfasını ziyaret et\n"
            "✅ Ziyaret ettikten sonra **bitti** yaz ve 1 coin kazan!"
        ),
        'task_assigned_with_owner': (
            "📩 Görevin:\n{}\n\n"
            "👤 Link Sahibi: {} (ID: {})\n\n"
            "🔗 Yukarıdaki linke tıklayıp Temu sayfasını ziyaret et\n"
            "✅ Ziyaret ettikten sonra **bitti** yaz ve 1 coin kazan!"
        ),
        'task_assignment_error': "❌ Görev atanırken bir hata oluştu.",
        'no_leaderboard': "Henüz liderlik tablosu yok.",
        'leaderboard_title': "🏆 En çok coin kazananlar:\n\n",
        'daily_reward_claimed': '🎁 Günlük ödülünüz alındı!\n💰 {} coin kazandınız!\n🔥 Seri: {} gün',
        'daily_reward_already_claimed': '⏰ Günlük ödülünüzü bugün zaten aldınız!\n🔥 Mevcut seri: {} gün\n📅 Yarın tekrar gelin!',
        'daily_reward_error': '❌ Ödül alma işlemi başarısız!',
        'link_save_error': "❌ Link kaydedilirken bir hata oluştu.",
        'language_selection': "🌐 Dil Seçimi / Language Selection",
        'select_language': "Dil seçin / Choose language:",
        'turkish_button': "🇹🇷 Türkçe",
        'english_button': "🇺🇸 English",
        
        # New Features - Turkish translations
        'referral_code_created': "🔗 Referans kodunuz: {}\n\nBu kodu arkadaşlarınızla paylaşın!\n• Arkadaşınız 10 coin kazanır\n• Siz 20 coin kazanırsınız",
        'referral_stats': "👥 **Referans İstatistikleri**\n\n🔗 Kodunuz: {}\n👫 Davet ettiğiniz: {} kişi\n💰 Kazandığınız coin: {} coin",
        'referral_applied': "✅ Referans kodu uygulandı! 10 coin kazandınız!",
        'referral_bonus': "🎉 {} referans kodunuzu kullandı! 20 coin kazandınız!",
        'level_up': "🎉 Seviye atladınız! Artık {} seviyesiniz: {}",
        'level_info': "📊 **Seviye Bilgileri**\n\n{} Seviye: {} ({})\n🎯 Toplam görevler: {}\n📈 Deneyim: {} XP\n⚡ Bu hafta: {} görev",
        'achievement_earned': "🏆 Yeni başarı kazandınız: {}",
        'achievements_list': "🏆 **Başarılarınız** ({})\n\n{}",
        'no_achievements': "Henüz hiç başarınız yok. Görev tamamlayarak başarı kazanabilirsiniz!",
        'profile_info': "👤 **{} Profili**\n\n{}{} Seviye: {} ({})\n💰 Coin: {}\n🎯 Toplam görevler: {}\n📈 Deneyim: {} XP\n👥 Referanslar: {} kişi\n🏆 Başarılar: {} kazanıldı{}",
        'premium_status': "\n⭐ Premium: {} tarihine kadar",
        'shop_menu': "🛒 **TemuXpress Mağaza**\n\n💰 Coin bakiyeniz: {}\n\nSatın almak istediğiniz ürünü seçin:",
        'item_purchased': "✅ {} başarıyla satın alındı!",
        'insufficient_coins': "❌ Yetersiz coin! Bu ürün için {} coin gerekli.",
        'already_purchased': "❌ Bu ürünü zaten satın aldınız!",
        'lottery_ticket_bought': "🎟️ #{} numaralı bilet satın alındı! Çekiliş yakında...",
        'lottery_already_bought': "❌ Bugün zaten bilet satın aldınız!",
        'dice_win': "🎲 Zar oyunu: Siz {} - Bot {}\n🎉 Kazandınız! +{} coin",
        'dice_lose': "🎲 Zar oyunu: Siz {} - Bot {}\n😔 Kaybettiniz! -{} coin",
        'dice_tie': "🎲 Zar oyunu: Siz {} - Bot {}\n🤝 Berabere!",
        'wheel_result': "🎰 Çark sonucu: {}",
        'weekly_leaderboard': "🏆 **Haftalık Liderlik Tablosu**\n\n{}",
        'weekly_reset': "🔄 Haftalık skorlar sıfırlandı! Yeni hafta başladı!",
        'help_menu': """📋 **Komut Listesi**

🎯 **Temel Komutlar:**
/start - Botu başlat
/gonder - Link gönder
/gorev - Görev al
/coin - Coin bakiyesi
/gunluk - Günlük ödül

📊 **Profil & Seviye:**
/profile - Profilinizi görüntüle
/level - Seviye bilgileri
/achievements - Başarılarınız

👥 **Referans Sistemi:**
/ref - Referans kodunuz
/refstat - Referans istatistikleri

🛒 **Mağaza & Oyunlar:**
/shop - Mağaza
/lottery - Piyango bileti
/dice - Zar oyunu
/wheel - Şans çarkı

📈 **Lider Tabloları:**
/top - Genel lider tablosu
/weekly - Haftalık lider tablosu

🔧 **Diğer:**
/dil - Dil değiştir
/help - Bu yardım menüsü"""
    },
    'en': {
        'welcome_title': "👋 Welcome to TemuXpress!",
        'welcome_intro': (
            "🎯 This system is designed for sharing Temu links and earning coins.\n\n"
            "📖 How It Works:\n"
            "• Add your Temu link\n"
            "• Visit other users' links\n"
            "• Earn coins for each completed task\n"
            "• Climb the leaderboard!\n\n"
            "🎮 Choose your language to get started:"
        ),
        'language_selected': "🇺🇸 English selected! You can now use the commands:",
        'commands_menu': (
            "📋 Commands:\n"
            "🔗 /gonder - Add link\n"
            "💼 /gorev - Get task\n"
            "💰 /coin - Check coins\n"
            "🎁 /gunluk - Daily reward\n"
            "📋 /benimlinkim - View my link\n"
            "🏆 /top - Leaderboard\n"
            "🤖 /durum - Bot status\n"
            "🌐 /dil - Change language\n"
            "❓ /help - View all commands"
        ),
        'send_link_prompt': (
            "📎 Please send your Temu link:\n\n"
            "ℹ️ Link must contain 'temu.com'."
        ),
        'link_saved': (
            "✅ Link saved successfully!\n\n"
            "💡 You can now get tasks with /gorev command."
        ),
        'invalid_link': (
            "❌ This is not a valid Temu link.\n\n"
            "🔍 Link must contain 'temu.com'."
        ),
        'task_completed': "✅ Task completed! You earned 1 coin. 🎉",
        'task_error': "❌ An error occurred while completing the task.",
        'no_active_task': "❌ You don't have an active task.",
        'coin_count': "💰 Your coins: {}",
        'your_link': "🔗 Your saved link:\n{}",
        'no_link_saved': (
            "❌ You haven't added a link yet.\n\n"
            "📎 Use /gonder command to add a link."
        ),
        'need_link_first': (
            "❌ You need to add your link first.\n\n"
            "📎 Use /gonder command."
        ),
        'already_has_task': (
            "🔁 You already have an active task.\n\n"
            "✅ Don't forget to write 'bitti' when you complete your task."
        ),
        'no_tasks_available': (
            "⏳ No tasks available right now.\n\n"
            "💡 Try again later or more coins may need to be earned if there are no links you haven't completed yet."
        ),
        'task_assigned': (
            "📩 Your task:\n{}\n\n"
            "🔗 Click the link above to visit the Temu page\n"
            "✅ After visiting, write **bitti** to complete and earn 1 coin!"
        ),
        'task_assigned_with_owner': (
            "📩 Your task:\n{}\n\n"
            "👤 Link Owner: {} (ID: {})\n\n"
            "🔗 Click the link above to visit the Temu page\n"
            "✅ After visiting, write **bitti** to complete and earn 1 coin!"
        ),
        'task_assignment_error': "❌ An error occurred while assigning the task.",
        'no_leaderboard': 'No leaderboard available yet.',
        'leaderboard_title': '🏆 Leaderboard:\n\n',
        'daily_reward_claimed': '🎁 Daily reward claimed!\n💰 You earned {} coins!\n🔥 Streak: {} days',
        'daily_reward_already_claimed': '⏰ You already claimed your daily reward today!\n🔥 Current streak: {} days\n📅 Come back tomorrow!',
        'daily_reward_error': '❌ Failed to claim daily reward!',
        'link_save_error': "❌ An error occurred while saving the link.",
        'language_selection': "🌐 Language Selection / Dil Seçimi",
        'select_language': "Choose language / Dil seçin:",
        'turkish_button': "🇹🇷 Türkçe",
        'english_button': "🇺🇸 English",
        
        # New Features - Turkish
        'referral_code_created': "🔗 Referans kodunuz: {}\n\nBu kodu arkadaşlarınızla paylaşın!\n• Arkadaşınız 10 coin kazanır\n• Siz 20 coin kazanırsınız",
        'referral_stats': "👥 **Referans İstatistikleri**\n\n🔗 Kodunuz: {}\n👫 Davet ettikleriniz: {} kişi\n💰 Kazanılan coin: {} coin",
        'referral_applied': "✅ Referans kodu uygulandı! +10 coin kazandınız!",
        'referral_bonus': "🎉 {} kullanıcısı referans kodunuzu kullandı! +20 coin kazandınız!",
        'level_up': "🎉 Seviye atladınız! Şimdi {} seviyesiniz: {}",
        'level_info': "📊 **Seviye Bilgileri**\n\n{} Seviye: {} ({})\n🎯 Toplam görev: {}\n📈 Deneyim: {} XP\n⚡ Bu hafta: {} görev",
        'achievement_earned': "🏆 Yeni başarı kazandınız: {}",
        'achievements_list': "🏆 **Başarılarınız** ({})\n\n{}",
        'no_achievements': "Henüz hiç başarınız yok. Görevleri tamamlayarak başarı kazanın!",
        'profile_info': "👤 **{} Profili**\n\n{}{} Seviye: {} ({})\n💰 Coin: {}\n🎯 Toplam görev: {}\n📈 Deneyim: {} XP\n👥 Referans: {} kişi\n🏆 Başarı: {} adet{}",
        'premium_status': "\n⭐ Premium: {} tarihine kadar",
        'shop_menu': "🛒 **TemuXpress Mağazası**\n\n💰 Coin bakiyeniz: {}\n\nSatın almak istediğiniz öğeyi seçin:",
        'item_purchased': "✅ {} başarıyla satın alındı!",
        'insufficient_coins': "❌ Yetersiz coin! Bu öğe için {} coin gerekli.",
        'already_purchased': "❌ Bu öğeyi zaten satın aldınız!",
        'lottery_ticket_bought': "🎟️ Bilet #{} satın alındı! Şans çekimi yakında...",
        'lottery_already_bought': "❌ Bugün zaten bilet aldınız!",
        'dice_win': "🎲 Zar oyunu: Siz {} - Bot {}\n🎉 Kazandınız! +{} coin",
        'dice_lose': "🎲 Zar oyunu: Siz {} - Bot {}\n😔 Kaybettiniz! -{} coin",
        'dice_tie': "🎲 Zar oyunu: Siz {} - Bot {}\n🤝 Berabere!",
        'wheel_result': "🎰 Şans çarkı sonucu: {}",
        'weekly_leaderboard': "🏆 **Haftalık Lider Tablosu**\n\n{}",
        'weekly_reset': "🔄 Haftalık skorlar sıfırlandı! Yeni hafta başladı!",
        'help_menu': """📋 **Komut Listesi**

🎯 **Temel Komutlar:**
/start - Botu başlat
/gonder - Link gönder
/gorev - Görev al
/coin - Coin bakiyesi
/gunluk - Günlük ödül

📊 **Profil & Seviye:**
/profile - Profilinizi görüntüle
/level - Seviye bilgileri
/achievements - Başarılarınız

👥 **Referans Sistemi:**
/ref - Referans kodunuz
/refstat - Referans istatistikleri

🛒 **Mağaza & Oyunlar:**
/shop - Mağaza
/lottery - Piyango bileti
/dice - Zar oyunu
/wheel - Şans çarkı

📈 **Lider Tabloları:**
/top - Genel lider tablosu
/weekly - Haftalık lider tablosu

🔧 **Diğer:**
/dil - Dil değiştir
/help - Bu yardım menüsü""",
        
        # New Features
        'referral_code_created': "🔗 Your referral code: {}\n\nShare this code with your friends!\n• Your friend earns 10 coins\n• You earn 20 coins",
        'referral_stats': "👥 **Referral Statistics**\n\n🔗 Your code: {}\n👫 People invited: {} people\n💰 Coins earned: {} coins",
        'referral_applied': "✅ Referral code applied! You earned +10 coins!",
        'referral_bonus': "🎉 {} used your referral code! You earned +20 coins!",
        'level_up': "🎉 Level up! You are now level {}: {}",
        'level_info': "📊 **Level Information**\n\n{} Level: {} ({})\n🎯 Total tasks: {}\n📈 Experience: {} XP\n⚡ This week: {} tasks",
        'achievement_earned': "🏆 New achievement earned: {}",
        'achievements_list': "🏆 **Your Achievements** ({})\n\n{}",
        'no_achievements': "You don't have any achievements yet. Complete tasks to earn achievements!",
        'profile_info': "👤 **{} Profile**\n\n{}{} Level: {} ({})\n💰 Coins: {}\n🎯 Total tasks: {}\n📈 Experience: {} XP\n👥 Referrals: {} people\n🏆 Achievements: {} earned{}",
        'premium_status': "\n⭐ Premium: Until {}",
        'shop_menu': "🛒 **TemuXpress Shop**\n\n💰 Your coin balance: {}\n\nSelect the item you want to purchase:",
        'item_purchased': "✅ {} purchased successfully!",
        'insufficient_coins': "❌ Insufficient coins! This item requires {} coins.",
        'already_purchased': "❌ You already purchased this item!",
        'lottery_ticket_bought': "🎟️ Ticket #{} purchased! Draw coming soon...",
        'lottery_already_bought': "❌ You already bought a ticket today!",
        'dice_win': "🎲 Dice game: You {} - Bot {}\n🎉 You won! +{} coins",
        'dice_lose': "🎲 Dice game: You {} - Bot {}\n😔 You lost! -{} coins",
        'dice_tie': "🎲 Dice game: You {} - Bot {}\n🤝 It's a tie!",
        'wheel_result': "🎰 Wheel result: {}",
        'weekly_leaderboard': "🏆 **Weekly Leaderboard**\n\n{}",
        'weekly_reset': "🔄 Weekly scores reset! New week started!",
        'help_menu': """📋 **Command List**

🎯 **Basic Commands:**
/start - Start the bot
/gonder - Send link
/gorev - Get task
/coin - Coin balance
/gunluk - Daily reward

📊 **Profile & Level:**
/profile - View your profile
/level - Level information
/achievements - Your achievements

👥 **Referral System:**
/ref - Your referral code
/refstat - Referral statistics

🛒 **Shop & Games:**
/shop - Shop
/lottery - Lottery ticket
/dice - Dice game
/wheel - Wheel of fortune

📈 **Leaderboards:**
/top - General leaderboard
/weekly - Weekly leaderboard

🔧 **Other:**
/durum - Bot status
/dil - Change language
/help - This help menu"""
    }
}

def get_text(user_language, key, *args):
    """Get translated text for the user's language."""
    language = user_language if user_language in LANGUAGES else 'tr'  # Default to Turkish
    text = LANGUAGES[language].get(key, LANGUAGES['tr'].get(key, key))

    if args:
        return text.format(*args)
    return text

def get_user_language(user_id):
    """Get user's preferred language from database."""
    from database import get_user_language as db_get_user_language
    return db_get_user_language(user_id) or 'tr'  # Default to Turkish