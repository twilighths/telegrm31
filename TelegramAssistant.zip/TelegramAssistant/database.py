import sqlite3
import threading
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

# Thread-safe database connection
_local = threading.local()

def get_db_connection():
    """Get a thread-safe database connection."""
    # Always create a new connection to avoid "closed database" errors
    conn = sqlite3.connect("temuxpress.db", check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    """Initialize the database with required tables."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Create users table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            link TEXT,
            coin INTEGER DEFAULT 0,
            pending INTEGER DEFAULT 0,
            language TEXT DEFAULT 'tr',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """)

        # Create task completions table to track user-link pairs
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS task_completions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            target_user_id INTEGER,
            link TEXT,
            completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, target_user_id)
        )
        """)

        # Check if language column exists, if not add it
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]
        if 'language' not in columns:
            cursor.execute("ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'tr'")
            logger.info("Added language column to users table")

        # Create daily rewards table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS daily_rewards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            reward_date DATE,
            reward_amount INTEGER DEFAULT 5,
            claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, reward_date)
        )
        """)

        # Create referrals table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            referrer_id INTEGER NOT NULL,
            referred_id INTEGER NOT NULL,
            referral_code TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (referrer_id) REFERENCES users (user_id),
            FOREIGN KEY (referred_id) REFERENCES users (user_id)
        )
        """)
        
        # Create achievements table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS achievements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            achievement_type TEXT NOT NULL,
            achievement_name TEXT NOT NULL,
            earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
        """)
        
        # Create user_levels table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_levels (
            user_id INTEGER PRIMARY KEY,
            level INTEGER DEFAULT 1,
            total_tasks INTEGER DEFAULT 0,
            weekly_tasks INTEGER DEFAULT 0,
            weekly_reset_date DATE,
            experience_points INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
        """)
        
        # Create lottery_entries table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS lottery_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            entry_date DATE NOT NULL,
            ticket_number INTEGER NOT NULL,
            is_winner BOOLEAN DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
        """)
        
        # Create shop_purchases table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS shop_purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            item_type TEXT NOT NULL,
            item_name TEXT NOT NULL,
            cost INTEGER NOT NULL,
            purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
        """)
        
        # Add new columns to users table if they don't exist
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'referral_code' not in columns:
            cursor.execute('ALTER TABLE users ADD COLUMN referral_code TEXT')
        if 'referred_by' not in columns:
            cursor.execute('ALTER TABLE users ADD COLUMN referred_by INTEGER')
        if 'premium_until' not in columns:
            cursor.execute('ALTER TABLE users ADD COLUMN premium_until DATE')
        if 'profile_title' not in columns:
            cursor.execute('ALTER TABLE users ADD COLUMN profile_title TEXT')
        if 'auto_task_enabled' not in columns:
            cursor.execute('ALTER TABLE users ADD COLUMN auto_task_enabled BOOLEAN DEFAULT 0')

        # Create indexes for better performance
        cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_users_coin ON users(coin DESC)
        """)

        cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_users_pending ON users(pending)
        """)

        cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_daily_rewards_user_date ON daily_rewards(user_id, reward_date)
        """)
        
        cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code)
        """)
        
        cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_referrals_referrer ON referrals(referrer_id)
        """)
        
        cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_achievements_user ON achievements(user_id)
        """)
        
        cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_lottery_entries_user ON lottery_entries(user_id)
        """)

        conn.commit()
        logger.info("Database initialized successfully.")

    except sqlite3.Error as e:
        logger.error(f"Database initialization error: {e}")
        raise

def register_user(user_id, username):
    """Register a new user or update existing user."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)",
            (user_id, username)
        )
        # Update username if user already exists
        cursor.execute(
            "UPDATE users SET username = ? WHERE user_id = ?",
            (username, user_id)
        )
        conn.commit()
        return True
    except sqlite3.Error as e:
        logger.error(f"Error registering user {user_id}: {e}")
        return False

def save_user_link(user_id, link):
    """Save or update user's Temu link."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "UPDATE users SET link = ? WHERE user_id = ?",
            (link, user_id)
        )
        conn.commit()
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        logger.error(f"Error saving link for user {user_id}: {e}")
        return False

def get_user_coins(user_id):
    """Get user's coin count."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT coin FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result[0] if result else 0
    except sqlite3.Error as e:
        logger.error(f"Error getting coins for user {user_id}: {e}")
        return 0
    finally:
        conn.close()

def get_user_link(user_id):
    """Get user's saved link."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT link FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result[0] if result and result[0] else None
    except sqlite3.Error as e:
        logger.error(f"Error getting link for user {user_id}: {e}")
        return None

def has_user_link(user_id):
    """Check if user has a saved link."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT link FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result and result[0] is not None
    except sqlite3.Error as e:
        logger.error(f"Error checking link for user {user_id}: {e}")
        return False

def is_user_pending(user_id):
    """Check if user has a pending task."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT pending FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result and result[0] == 1
    except sqlite3.Error as e:
        logger.error(f"Error checking pending status for user {user_id}: {e}")
        return False

def set_user_pending(user_id, pending_status):
    """Set user's pending task status."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "UPDATE users SET pending = ? WHERE user_id = ?",
            (pending_status, user_id)
        )
        conn.commit()
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        logger.error(f"Error setting pending status for user {user_id}: {e}")
        return False

def add_user_coins(user_id, amount):
    """Add coins to user's account."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "UPDATE users SET coin = coin + ? WHERE user_id = ?",
            (amount, user_id)
        )
        conn.commit()
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        logger.error(f"Error adding coins to user {user_id}: {e}")
        return False
    finally:
        conn.close()

def subtract_user_coins(user_id, amount):
    """Subtract coins from user's account."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "UPDATE users SET coin = coin - ? WHERE user_id = ? AND coin >= ?",
            (amount, user_id, amount)
        )
        conn.commit()
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        logger.error(f"Error subtracting coins from user {user_id}: {e}")
        return False
    finally:
        conn.close()

def get_task_target(current_user_id):
    """Get a user to assign a task to (excluding current user)."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT user_id, link FROM users 
            WHERE coin > 0 AND user_id != ? AND link IS NOT NULL 
            ORDER BY coin DESC LIMIT 1
        """, (current_user_id,))
        result = cursor.fetchone()
        return (result[0], result[1]) if result else (None, None)
    except sqlite3.Error as e:
        logger.error(f"Error getting task target: {e}")
        return (None, None)

def get_leaderboard(limit=5):
    """Get top users by coin count."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "SELECT user_id, username, coin FROM users ORDER BY coin DESC LIMIT ?",
            (limit,)
        )
        return cursor.fetchall()
    except sqlite3.Error as e:
        logger.error(f"Error getting leaderboard: {e}")
        return []

def get_user_language(user_id):
    """Get user's preferred language."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT language FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        return result[0] if result and result[0] else 'tr'  # Default to Turkish
    except sqlite3.Error as e:
        logger.error(f"Error getting language for user {user_id}: {e}")
        return 'tr'

def set_user_language(user_id, language):
    """Set user's preferred language."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "UPDATE users SET language = ? WHERE user_id = ?",
            (language, user_id)
        )
        conn.commit()
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        logger.error(f"Error setting language for user {user_id}: {e}")
        return False

def has_completed_task_for_user(user_id, target_user_id):
    """Check if user has already completed a task for the target user."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "SELECT COUNT(*) FROM task_completions WHERE user_id = ? AND target_user_id = ?",
            (user_id, target_user_id)
        )
        result = cursor.fetchone()
        return result[0] > 0
    except sqlite3.Error as e:
        logger.error(f"Error checking task completion for user {user_id}, target {target_user_id}: {e}")
        return True  # Return True to be safe and prevent duplicate tasks

def record_task_completion(user_id, target_user_id, link):
    """Record that a user has completed a task for a target user."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "INSERT OR IGNORE INTO task_completions (user_id, target_user_id, link) VALUES (?, ?, ?)",
            (user_id, target_user_id, link)
        )
        conn.commit()
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        logger.error(f"Error recording task completion for user {user_id}, target {target_user_id}: {e}")
        return False

def get_available_task_target(current_user_id):
    """Get a user to assign a task to (excluding completed ones and current user)."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Find users with coins and links who the current user hasn't completed tasks for
        cursor.execute("""
            SELECT u.user_id, u.link, u.username 
            FROM users u 
            WHERE u.coin > 0 
            AND u.user_id != ? 
            AND u.link IS NOT NULL 
            AND u.user_id NOT IN (
                SELECT tc.target_user_id 
                FROM task_completions tc 
                WHERE tc.user_id = ?
            )
            ORDER BY u.coin DESC 
            LIMIT 1
        """, (current_user_id, current_user_id))

        result = cursor.fetchone()
        return (result[0], result[1], result[2]) if result else (None, None, None)
    except sqlite3.Error as e:
        logger.error(f"Error getting available task target: {e}")
        return (None, None, None)

def can_claim_daily_reward(user_id):
    """Check if user can claim daily reward today."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        today = datetime.now().date()
        cursor.execute(
            "SELECT COUNT(*) FROM daily_rewards WHERE user_id = ? AND reward_date = ?",
            (user_id, today)
        )
        result = cursor.fetchone()
        return result[0] == 0
    except sqlite3.Error as e:
        logger.error(f"Error checking daily reward for user {user_id}: {e}")
        return False

def claim_daily_reward(user_id, reward_amount=5):
    """Claim daily reward for user."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        today = datetime.now().date()

        # Check if already claimed today
        if not can_claim_daily_reward(user_id):
            return False

        # Add reward record
        cursor.execute(
            "INSERT INTO daily_rewards (user_id, reward_date, reward_amount) VALUES (?, ?, ?)",
            (user_id, today, reward_amount)
        )

        # Add coins to user
        cursor.execute(
            "UPDATE users SET coin = coin + ? WHERE user_id = ?",
            (reward_amount, user_id)
        )

        conn.commit()
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        logger.error(f"Error claiming daily reward for user {user_id}: {e}")
        return False

def get_daily_reward_streak(user_id):
    """Get user's daily reward streak."""
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT reward_date FROM daily_rewards 
            WHERE user_id = ? 
            ORDER BY reward_date DESC 
            LIMIT 30
        """, (user_id,))

        dates = [row[0] for row in cursor.fetchall()]
        if not dates:
            return 0

        # Convert string dates to date objects if needed
        from datetime import datetime, date
        if isinstance(dates[0], str):
            dates = [datetime.strptime(d, '%Y-%m-%d').date() for d in dates]

        # Calculate streak
        streak = 0
        today = date.today()
        expected_date = today

        for reward_date in dates:
            if reward_date == expected_date:
                streak += 1
                expected_date = date.fromordinal(expected_date.toordinal() - 1)
            else:
                break

        return streak
    except sqlite3.Error as e:
        logger.error(f"Error getting daily reward streak for user {user_id}: {e}")
        return 0

def get_active_users_stats():
    """Get statistics about active users."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Total users
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        # Users with links
        cursor.execute("SELECT COUNT(*) FROM users WHERE link IS NOT NULL")
        users_with_links = cursor.fetchone()[0]
        
        # Users with coins
        cursor.execute("SELECT COUNT(*) FROM users WHERE coin > 0")
        users_with_coins = cursor.fetchone()[0]
        
        # Users with pending tasks
        cursor.execute("SELECT COUNT(*) FROM users WHERE pending = 1")
        users_with_pending_tasks = cursor.fetchone()[0]
        
        # Total coins in system
        cursor.execute("SELECT COALESCE(SUM(coin), 0) FROM users")
        total_coins = cursor.fetchone()[0]
        
        # Total task completions
        cursor.execute("SELECT COUNT(*) FROM task_completions")
        total_completions = cursor.fetchone()[0]
        
        # Average coins per user
        avg_coins = total_coins / total_users if total_users > 0 else 0
        
        return {
            'total_users': total_users,
            'users_with_links': users_with_links,
            'users_with_coins': users_with_coins,
            'users_with_pending_tasks': users_with_pending_tasks,
            'total_coins': total_coins,
            'total_completions': total_completions,
            'avg_coins': round(avg_coins, 2)
        }
    except sqlite3.Error as e:
        logger.error(f"Error getting active users stats: {e}")
        return {
            'total_users': 0,
            'users_with_links': 0,
            'users_with_coins': 0,
            'users_with_pending_tasks': 0,
            'total_coins': 0,
            'total_completions': 0,
            'avg_coins': 0
        }

# ================================
# REFERRAL SYSTEM FUNCTIONS
# ================================

import string
import random

def generate_referral_code():
    """Generate a unique referral code."""
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

def create_referral_code(user_id):
    """Create a referral code for a user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if user already has a referral code
        cursor.execute("SELECT referral_code FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        
        if result and result[0]:
            return result[0]
        
        # Generate new referral code
        referral_code = generate_referral_code()
        
        # Ensure uniqueness
        while True:
            cursor.execute("SELECT COUNT(*) FROM users WHERE referral_code = ?", (referral_code,))
            if cursor.fetchone()[0] == 0:
                break
            referral_code = generate_referral_code()
        
        # Update user with referral code
        cursor.execute("UPDATE users SET referral_code = ? WHERE user_id = ?", (referral_code, user_id))
        conn.commit()
        
        return referral_code
        
    except sqlite3.Error as e:
        logger.error(f"Error creating referral code for user {user_id}: {e}")
        return None
    finally:
        conn.close()

def apply_referral_code(user_id, referral_code):
    """Apply a referral code when a user joins."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Find referrer
        cursor.execute("SELECT user_id FROM users WHERE referral_code = ?", (referral_code,))
        referrer = cursor.fetchone()
        
        if not referrer:
            return False, "Geçersiz referans kodu"
        
        referrer_id = referrer[0]
        
        # Check if user already has a referrer
        cursor.execute("SELECT referred_by FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        
        if result and result[0]:
            return False, "Zaten bir referans kodu kullanmışsınız"
        
        # Don't allow self-referral
        if referrer_id == user_id:
            return False, "Kendi referans kodunuzu kullanamazsınız"
        
        # Update referred user
        cursor.execute("UPDATE users SET referred_by = ? WHERE user_id = ?", (referrer_id, user_id))
        
        # Add referral record
        cursor.execute("""
            INSERT INTO referrals (referrer_id, referred_id, referral_code)
            VALUES (?, ?, ?)
        """, (referrer_id, user_id, referral_code))
        
        # Give bonus coins
        add_user_coins(referrer_id, 20)  # Referrer gets 20 coins
        add_user_coins(user_id, 10)     # New user gets 10 coins
        
        conn.commit()
        return True, "Referans kodu başarıyla uygulandı!"
        
    except sqlite3.Error as e:
        logger.error(f"Error applying referral code: {e}")
        return False, "Bir hata oluştu"
    finally:
        conn.close()

def get_referral_stats(user_id):
    """Get referral statistics for a user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get referral code
        cursor.execute("SELECT referral_code FROM users WHERE user_id = ?", (user_id,))
        referral_code = cursor.fetchone()
        referral_code = referral_code[0] if referral_code else None
        
        # Get referral count
        cursor.execute("SELECT COUNT(*) FROM referrals WHERE referrer_id = ?", (user_id,))
        referral_count = cursor.fetchone()[0]
        
        # Get referred users
        cursor.execute("""
            SELECT u.username, r.created_at
            FROM referrals r
            JOIN users u ON r.referred_id = u.user_id
            WHERE r.referrer_id = ?
            ORDER BY r.created_at DESC
        """, (user_id,))
        referred_users = cursor.fetchall()
        
        return {
            'referral_code': referral_code,
            'referral_count': referral_count,
            'referred_users': referred_users
        }
        
    except sqlite3.Error as e:
        logger.error(f"Error getting referral stats: {e}")
        return {'referral_code': None, 'referral_count': 0, 'referred_users': []}
    finally:
        conn.close()

# ================================
# LEVEL SYSTEM FUNCTIONS
# ================================

def get_user_level(user_id):
    """Get user's level information."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM user_levels WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        
        if not result:
            # Create new level record
            cursor.execute("""
                INSERT INTO user_levels (user_id, level, total_tasks, weekly_tasks, experience_points)
                VALUES (?, 1, 0, 0, 0)
            """, (user_id,))
            conn.commit()
            return {'level': 1, 'total_tasks': 0, 'weekly_tasks': 0, 'experience_points': 0}
        
        return {
            'level': result[1],
            'total_tasks': result[2],
            'weekly_tasks': result[3],
            'experience_points': result[5]
        }
        
    except sqlite3.Error as e:
        logger.error(f"Error getting user level: {e}")
        return {'level': 1, 'total_tasks': 0, 'weekly_tasks': 0, 'experience_points': 0}
    finally:
        conn.close()

def update_user_level(user_id, task_completed=False):
    """Update user's level and experience."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get current level data
        level_data = get_user_level(user_id)
        
        if task_completed:
            new_total_tasks = level_data['total_tasks'] + 1
            new_weekly_tasks = level_data['weekly_tasks'] + 1
            new_experience = level_data['experience_points'] + 10
            
            # Calculate new level
            new_level = min(10, (new_total_tasks // 10) + 1)
            
            cursor.execute("""
                UPDATE user_levels 
                SET level = ?, total_tasks = ?, weekly_tasks = ?, experience_points = ?
                WHERE user_id = ?
            """, (new_level, new_total_tasks, new_weekly_tasks, new_experience, user_id))
            
            conn.commit()
            
            # Check if level up occurred
            if new_level > level_data['level']:
                return True, new_level
        
        return False, level_data['level']
        
    except sqlite3.Error as e:
        logger.error(f"Error updating user level: {e}")
        return False, 1
    finally:
        conn.close()

def get_level_name(level):
    """Get level name based on level number."""
    level_names = {
        1: "🥉 Bronz",
        2: "🥉 Bronz+",
        3: "🥈 Gümüş",
        4: "🥈 Gümüş+",
        5: "🥇 Altın",
        6: "🥇 Altın+",
        7: "💎 Elmas",
        8: "💎 Elmas+",
        9: "👑 Efsane",
        10: "🏆 Şampiyon"
    }
    return level_names.get(level, "🥉 Bronz")

# ================================
# ACHIEVEMENT SYSTEM FUNCTIONS
# ================================

def add_achievement(user_id, achievement_type, achievement_name):
    """Add an achievement to a user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if already has this achievement
        cursor.execute("""
            SELECT COUNT(*) FROM achievements 
            WHERE user_id = ? AND achievement_type = ?
        """, (user_id, achievement_type))
        
        if cursor.fetchone()[0] > 0:
            return False
        
        # Add achievement
        cursor.execute("""
            INSERT INTO achievements (user_id, achievement_type, achievement_name)
            VALUES (?, ?, ?)
        """, (user_id, achievement_type, achievement_name))
        
        conn.commit()
        return True
        
    except sqlite3.Error as e:
        logger.error(f"Error adding achievement: {e}")
        return False
    finally:
        conn.close()

def get_user_achievements(user_id):
    """Get user's achievements."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT achievement_type, achievement_name, earned_at
            FROM achievements
            WHERE user_id = ?
            ORDER BY earned_at DESC
        """, (user_id,))
        
        return cursor.fetchall()
        
    except sqlite3.Error as e:
        logger.error(f"Error getting achievements: {e}")
        return []
    finally:
        conn.close()

def check_achievements(user_id):
    """Check and award achievements for a user."""
    achievements_awarded = []
    
    # Get user stats
    coin_count = get_user_coins(user_id)
    level_data = get_user_level(user_id)
    referral_stats = get_referral_stats(user_id)
    
    # Check achievements
    achievements_to_check = [
        (coin_count >= 10, "first_coins", "🪙 İlk 10 Coin"),
        (coin_count >= 100, "coin_collector", "💰 Coin Koleksiyoncusu"),
        (coin_count >= 500, "coin_master", "🏆 Coin Ustası"),
        (level_data['total_tasks'] >= 1, "first_task", "🎯 İlk Görev"),
        (level_data['total_tasks'] >= 10, "task_warrior", "⚔️ Görev Savaşçısı"),
        (level_data['total_tasks'] >= 50, "task_master", "🏅 Görev Ustası"),
        (referral_stats['referral_count'] >= 1, "first_referral", "👥 İlk Referans"),
        (referral_stats['referral_count'] >= 5, "referral_expert", "🌟 Referans Uzmanı"),
        (level_data['level'] >= 5, "level_master", "📈 Seviye Ustası"),
    ]
    
    for condition, achievement_type, achievement_name in achievements_to_check:
        if condition:
            if add_achievement(user_id, achievement_type, achievement_name):
                achievements_awarded.append(achievement_name)
    
    return achievements_awarded

# ================================
# LOTTERY SYSTEM FUNCTIONS
# ================================

def buy_lottery_ticket(user_id, ticket_cost=50):
    """Buy a lottery ticket."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if user has enough coins
        current_coins = get_user_coins(user_id)
        if current_coins < ticket_cost:
            return False, "Yetersiz coin!"
        
        # Check if already bought ticket today
        today = datetime.now().date()
        cursor.execute("""
            SELECT COUNT(*) FROM lottery_entries 
            WHERE user_id = ? AND entry_date = ?
        """, (user_id, today))
        
        if cursor.fetchone()[0] > 0:
            return False, "Bugün zaten bilet aldınız!"
        
        # Generate ticket number
        cursor.execute("""
            SELECT MAX(ticket_number) FROM lottery_entries 
            WHERE entry_date = ?
        """, (today,))
        
        max_ticket = cursor.fetchone()[0] or 0
        ticket_number = max_ticket + 1
        
        # Buy ticket
        cursor.execute("""
            INSERT INTO lottery_entries (user_id, entry_date, ticket_number)
            VALUES (?, ?, ?)
        """, (user_id, today, ticket_number))
        
        subtract_user_coins(user_id, ticket_cost)
        conn.commit()
        
        return True, f"Bilet #{ticket_number} satın alındı!"
        
    except sqlite3.Error as e:
        logger.error(f"Error buying lottery ticket: {e}")
        return False, "Bir hata oluştu"
    finally:
        conn.close()

# ================================
# SHOP SYSTEM FUNCTIONS
# ================================

def get_shop_items():
    """Get available shop items."""
    return [
        {'id': 'title_vip', 'name': 'VIP Unvanı', 'type': 'title', 'cost': 200, 'description': 'Profilinizde VIP unvanı'},
        {'id': 'title_pro', 'name': 'PRO Unvanı', 'type': 'title', 'cost': 150, 'description': 'Profilinizde PRO unvanı'},
        {'id': 'title_star', 'name': 'STAR Unvanı', 'type': 'title', 'cost': 100, 'description': 'Profilinizde STAR unvanı'},
        {'id': 'auto_task', 'name': 'Otomatik Görev', 'type': 'feature', 'cost': 300, 'description': 'Otomatik görev alma özelliği'},
        {'id': 'premium_7', 'name': '7 Gün Premium', 'type': 'premium', 'cost': 500, 'description': '7 gün premium üyelik'},
        {'id': 'premium_30', 'name': '30 Gün Premium', 'type': 'premium', 'cost': 1500, 'description': '30 gün premium üyelik'},
    ]

def purchase_item(user_id, item_id):
    """Purchase an item from the shop."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Get item details
        items = get_shop_items()
        item = next((i for i in items if i['id'] == item_id), None)
        
        if not item:
            return False, "Geçersiz öğe!"
        
        # Check if user has enough coins within the same transaction
        cursor.execute("SELECT coin FROM users WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        current_coins = result[0] if result else 0
        
        if current_coins < item['cost']:
            return False, "Yetersiz coin!"
        
        # Check if already purchased (for certain items)
        if item['type'] == 'feature':
            cursor.execute("""
                SELECT COUNT(*) FROM shop_purchases 
                WHERE user_id = ? AND item_type = ? AND item_name = ?
            """, (user_id, item['type'], item['name']))
            
            if cursor.fetchone()[0] > 0:
                return False, "Bu öğeyi zaten satın aldınız!"
        
        # Purchase item
        cursor.execute("""
            INSERT INTO shop_purchases (user_id, item_type, item_name, cost)
            VALUES (?, ?, ?, ?)
        """, (user_id, item['type'], item['name'], item['cost']))
        
        # Subtract coins in the same transaction
        cursor.execute(
            "UPDATE users SET coin = coin - ? WHERE user_id = ? AND coin >= ?",
            (item['cost'], user_id, item['cost'])
        )
        
        # Apply item effects
        if item['type'] == 'title':
            cursor.execute("UPDATE users SET profile_title = ? WHERE user_id = ?", 
                          (item['name'], user_id))
        elif item['type'] == 'feature' and item['id'] == 'auto_task':
            cursor.execute("UPDATE users SET auto_task_enabled = 1 WHERE user_id = ?", 
                          (user_id,))
        elif item['type'] == 'premium':
            from datetime import timedelta
            days = 7 if item['id'] == 'premium_7' else 30
            premium_until = datetime.now().date() + timedelta(days=days)
            cursor.execute("UPDATE users SET premium_until = ? WHERE user_id = ?", 
                          (premium_until, user_id))
        
        conn.commit()
        return True, f"{item['name']} başarıyla satın alındı!"
        
    except sqlite3.Error as e:
        logger.error(f"Error purchasing item: {e}")
        return False, "Bir hata oluştu"
    finally:
        conn.close()

def get_user_profile(user_id):
    """Get user's complete profile."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT username, coin, profile_title, premium_until, auto_task_enabled
            FROM users WHERE user_id = ?
        """, (user_id,))
        
        result = cursor.fetchone()
        if not result:
            return None
        
        level_data = get_user_level(user_id)
        referral_stats = get_referral_stats(user_id)
        achievements = get_user_achievements(user_id)
        
        return {
            'username': result[0],
            'coin': result[1],
            'profile_title': result[2],
            'premium_until': result[3],
            'auto_task_enabled': result[4],
            'level': level_data['level'],
            'total_tasks': level_data['total_tasks'],
            'experience_points': level_data['experience_points'],
            'referral_count': referral_stats['referral_count'],
            'achievements_count': len(achievements)
        }
        
    except sqlite3.Error as e:
        logger.error(f"Error getting user profile: {e}")
        return None
    finally:
        conn.close()

def get_weekly_leaderboard():
    """Get weekly task leaderboard."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT u.username, ul.weekly_tasks, ul.level
            FROM user_levels ul
            JOIN users u ON ul.user_id = u.user_id
            WHERE ul.weekly_tasks > 0
            ORDER BY ul.weekly_tasks DESC, ul.level DESC
            LIMIT 10
        """)
        
        return cursor.fetchall()
        
    except sqlite3.Error as e:
        logger.error(f"Error getting weekly leaderboard: {e}")
        return []
    finally:
        conn.close()

def reset_weekly_tasks():
    """Reset weekly tasks for all users."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        from datetime import date
        today = date.today()
        
        cursor.execute("""
            UPDATE user_levels 
            SET weekly_tasks = 0, weekly_reset_date = ?
        """, (today,))
        
        conn.commit()
        return True
        
    except sqlite3.Error as e:
        logger.error(f"Error resetting weekly tasks: {e}")
        return False
    finally:
        conn.close()

# ================================
# GAMES SYSTEM FUNCTIONS
# ================================

def play_dice_game(user_id, bet_amount):
    """Play dice game with user."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if user has enough coins
        current_coins = get_user_coins(user_id)
        if current_coins < bet_amount:
            return False, "Yetersiz coin!", 0, 0
        
        # Roll dice
        import random
        user_roll = random.randint(1, 6)
        bot_roll = random.randint(1, 6)
        
        if user_roll > bot_roll:
            # User wins
            winnings = bet_amount * 2
            add_user_coins(user_id, winnings)
            return True, "Kazandınız!", user_roll, bot_roll
        elif user_roll < bot_roll:
            # User loses
            subtract_user_coins(user_id, bet_amount)
            return False, "Kaybettiniz!", user_roll, bot_roll
        else:
            # Tie
            return True, "Berabere!", user_roll, bot_roll
            
    except sqlite3.Error as e:
        logger.error(f"Error playing dice game: {e}")
        return False, "Bir hata oluştu!", 0, 0
    finally:
        conn.close()

def spin_wheel(user_id, spin_cost=25):
    """Spin the wheel game."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Check if user has enough coins
        current_coins = get_user_coins(user_id)
        if current_coins < spin_cost:
            return False, "Yetersiz coin!", 0
        
        # Spin wheel
        import random
        outcomes = [
            (5, "5 Coin"),
            (10, "10 Coin"),
            (25, "25 Coin"),
            (50, "50 Coin"),
            (100, "100 Coin"),
            (-spin_cost, "Kaybettiniz"),
            (0, "Tekrar deneyin")
        ]
        
        # Weighted random selection
        weights = [30, 25, 20, 15, 5, 3, 2]  # Higher chance for lower rewards
        result = random.choices(outcomes, weights=weights)[0]
        
        # Apply result
        subtract_user_coins(user_id, spin_cost)
        
        if result[0] > 0:
            add_user_coins(user_id, result[0])
        
        return True, result[1], result[0]
        
    except sqlite3.Error as e:
        logger.error(f"Error spinning wheel: {e}")
        return False, "Bir hata oluştu!", 0
    finally:
        conn.close()