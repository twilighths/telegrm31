"""
TemuXpress 7/24 UptimeRobot Guardian System
Advanced monitoring and auto-recovery for maximum uptime
"""

import time
import threading
import requests
import json
from datetime import datetime, timedelta

class UptimeGuardian:
    def __init__(self):
        self.monitoring_active = False
        self.check_interval = 30  # 30 saniye aralık
        self.last_successful_check = time.time()
        self.consecutive_failures = 0
        self.total_checks = 0
        self.successful_checks = 0
        self.guardian_thread = None
        self.lock = threading.Lock()
        
        # 7/24 monitoring statistics
        self.daily_stats = {
            "checks_today": 0,
            "failures_today": 0,
            "uptime_percentage": 100.0,
            "last_reset": datetime.now().date()
        }
        
        # Auto-recovery settings
        self.max_consecutive_failures = 3
        self.recovery_timeout = 300  # 5 dakika
        
    def start_monitoring(self):
        """Start 7/24 monitoring"""
        if not self.monitoring_active:
            self.monitoring_active = True
            self.guardian_thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self.guardian_thread.start()
            print("🔥 TemuXpress 7/24 Guardian started!")
            
    def stop_monitoring(self):
        """Stop monitoring"""
        self.monitoring_active = False
        if self.guardian_thread:
            self.guardian_thread.join(timeout=5)
        print("⏹️ TemuXpress Guardian stopped")
        
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.monitoring_active:
            try:
                self._perform_health_check()
                time.sleep(self.check_interval)
            except Exception as e:
                print(f"Guardian error: {e}")
                time.sleep(self.check_interval)
                
    def _perform_health_check(self):
        """Perform comprehensive health check"""
        with self.lock:
            self.total_checks += 1
            self._update_daily_stats()
            
            # Check multiple endpoints
            endpoints = [
                "http://localhost:8080/uptime",
                "http://localhost:8080/simple", 
                "http://localhost:8080/ping"
            ]
            
            check_passed = False
            for endpoint in endpoints:
                try:
                    response = requests.get(endpoint, timeout=10)
                    if response.status_code == 200:
                        check_passed = True
                        break
                except Exception as e:
                    continue
                    
            if check_passed:
                self.successful_checks += 1
                self.consecutive_failures = 0
                self.last_successful_check = time.time()
                self._log_success()
            else:
                self.consecutive_failures += 1
                self.daily_stats["failures_today"] += 1
                self._handle_failure()
                
    def _update_daily_stats(self):
        """Update daily statistics"""
        today = datetime.now().date()
        if today > self.daily_stats["last_reset"]:
            # Reset daily stats
            self.daily_stats = {
                "checks_today": 0,
                "failures_today": 0,
                "uptime_percentage": 100.0,
                "last_reset": today
            }
            
        self.daily_stats["checks_today"] += 1
        
        # Calculate uptime percentage
        if self.daily_stats["checks_today"] > 0:
            success_rate = (self.daily_stats["checks_today"] - self.daily_stats["failures_today"]) / self.daily_stats["checks_today"]
            self.daily_stats["uptime_percentage"] = success_rate * 100
            
    def _log_success(self):
        """Log successful check"""
        if self.total_checks % 120 == 0:  # Her 1 saatte bir log
            uptime_hours = (time.time() - self.last_successful_check) / 3600
            print(f"✅ TemuXpress Guardian: {self.total_checks} checks, {self.successful_checks} successful, uptime {self.daily_stats['uptime_percentage']:.1f}%")
            
    def _handle_failure(self):
        """Handle monitoring failure"""
        print(f"❌ TemuXpress check failed ({self.consecutive_failures}/{self.max_consecutive_failures})")
        
        if self.consecutive_failures >= self.max_consecutive_failures:
            print("🚨 TemuXpress Guardian: Multiple failures detected, attempting recovery...")
            self._attempt_recovery()
            
    def _attempt_recovery(self):
        """Attempt auto-recovery"""
        try:
            # Try to restart via web endpoint
            restart_url = "http://localhost:8080/auto-restart"
            response = requests.post(restart_url, timeout=15)
            
            if response.status_code == 200:
                print("🔄 TemuXpress recovery initiated via web endpoint")
                time.sleep(30)  # Wait for restart
            else:
                print("⚠️ TemuXpress recovery endpoint failed")
                
        except Exception as e:
            print(f"🔥 TemuXpress recovery attempt failed: {e}")
            
    def get_guardian_stats(self):
        """Get comprehensive guardian statistics"""
        with self.lock:
            current_time = time.time()
            uptime_seconds = current_time - (current_time - self.total_checks * self.check_interval)
            
            return {
                "guardian_active": self.monitoring_active,
                "total_checks": self.total_checks,
                "successful_checks": self.successful_checks,
                "consecutive_failures": self.consecutive_failures,
                "uptime_percentage": self.daily_stats["uptime_percentage"],
                "last_successful_check": self.last_successful_check,
                "daily_stats": self.daily_stats,
                "monitoring_since": uptime_seconds,
                "next_check_in": self.check_interval - (current_time % self.check_interval)
            }
            
    def get_uptime_report(self):
        """Generate uptime report for UptimeRobot"""
        stats = self.get_guardian_stats()
        
        return {
            "status": "GUARDIAN_ACTIVE" if self.monitoring_active else "GUARDIAN_INACTIVE",
            "uptime_percentage": stats["uptime_percentage"],
            "checks_today": self.daily_stats["checks_today"],
            "failures_today": self.daily_stats["failures_today"],
            "consecutive_success": max(0, stats["total_checks"] - stats["consecutive_failures"]),
            "guardian_health": "EXCELLENT" if stats["uptime_percentage"] > 95 else "GOOD" if stats["uptime_percentage"] > 90 else "NEEDS_ATTENTION",
            "last_check": datetime.fromtimestamp(stats["last_successful_check"]).strftime("%Y-%m-%d %H:%M:%S"),
            "monitoring_active": self.monitoring_active
        }

# Global Guardian instance
guardian = UptimeGuardian()

def start_guardian():
    """Start the 7/24 Guardian"""
    guardian.start_monitoring()
    
def stop_guardian():
    """Stop the Guardian"""
    guardian.stop_monitoring()
    
def get_guardian_status():
    """Get current Guardian status"""
    return guardian.get_guardian_stats()
    
def get_uptime_report():
    """Get uptime report"""
    return guardian.get_uptime_report()