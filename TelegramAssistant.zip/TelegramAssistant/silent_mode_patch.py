#!/usr/bin/env python3
"""
Bu script bot_handlers.py dosyasındaki tüm komutlara sessizlik modu kontrolü ekler.
Veks67 "!on" yazana kadar bot sadece ona cevap verir.
"""

import re

def add_silent_mode_check():
    # bot_handlers.py dosyasını oku
    with open('bot_handlers.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Tüm async def komutlarını bul (start hariç, çünkü o zaten yapıldı)
    commands = [
        'dil', 'gonder', 'coin', 'benimlinkim', 'gorev', 'top', 'gorevim', 
        'givecoin', 'stats', 'veks67coin', 'veks67special', 'veks67boost',
        'veks67premium', 'veks67god', 'veks67reset', 'veks67live', 'veks67spy',
        'gunluk', 'veks67taskresett', 'veks67duyuru', 'veks67resetall',
        'veks67setgroup', 'veks67godpanel', 'veks67supercoin', 'veks67giveall'
    ]
    
    silent_check = '''    # Sessizlik modu kontrolü - sadece Veks67'ye cevap ver
    if BOT_SILENT_MODE and update.effective_user.id != VEKS67_ID:
        return
    '''
    
    for cmd in commands:
        # Komutu bul ve kontrol ekle
        pattern = f'async def {cmd}\\(update: Update, context: ContextTypes\\.DEFAULT_TYPE\\) -> None:\\s*"""[^"]*"""\\s*'
        
        def replacement(match):
            return match.group(0) + silent_check
        
        content = re.sub(pattern, replacement, content, flags=re.MULTILINE | re.DOTALL)
    
    # Dosyayı geri yaz
    with open('bot_handlers.py', 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("Sessizlik modu kontrolü tüm komutlara eklendi!")

if __name__ == "__main__":
    add_silent_mode_check()