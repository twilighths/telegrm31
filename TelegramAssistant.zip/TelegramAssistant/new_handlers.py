import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database import (
    create_referral_code, apply_referral_code, get_referral_stats,
    get_user_level, update_user_level, get_level_name, check_achievements,
    add_achievement, get_user_achievements, get_user_profile,
    get_shop_items, purchase_item, buy_lottery_ticket, play_dice_game,
    spin_wheel, get_weekly_leaderboard, reset_weekly_tasks
)
from translations import get_text
from database import get_user_language

logger = logging.getLogger(__name__)

async def ref(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /ref command - show referral code."""
    user = update.effective_user
    user_lang = get_user_language(user.id)
    
    try:
        referral_code = create_referral_code(user.id)
        if referral_code:
            message = get_text(user_lang, 'referral_code_created', referral_code)
            await update.message.reply_text(message, parse_mode='Markdown')
        else:
            await update.message.reply_text("❌ Referans kodu oluşturulamadı!" if user_lang == 'tr' else "❌ Could not create referral code!")
    
    except Exception as e:
        logger.error(f"Error in ref command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def refstat(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /refstat command - show referral statistics."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        stats = get_referral_stats(user.id)
        if not stats['referral_code']:
            create_referral_code(user.id)
            stats = get_referral_stats(user.id)
        
        message = get_text(user_lang, 'referral_stats', 
                          stats['referral_code'], 
                          stats['referral_count'], 
                          stats['referral_count'] * 20)
        
        if stats['referred_users']:
            message += "\n\n👥 Davet ettikleriniz:" if user_lang == 'tr' else "\n\n👥 Your referrals:"
            for i, (username, date) in enumerate(stats['referred_users'][:5], 1):
                message += f"\n{i}. @{username}"
        
        await update.message.reply_text(message, parse_mode='Markdown')
    
    except Exception as e:
        logger.error(f"Error in refstat command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def apply_ref(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle referral code application."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    if not context.args:
        await update.message.reply_text(
            "❌ Kullanım: /refkod REFERANS_KODU" if user_lang == 'tr' else "❌ Usage: /refkod REFERRAL_CODE"
        )
        return
    
    referral_code = context.args[0].upper()
    
    try:
        success, message = apply_referral_code(user.id, referral_code)
        await update.message.reply_text(message)
        
        if success:
            # Check for achievements
            achievements = check_achievements(user.id)
            for achievement in achievements:
                await update.message.reply_text(
                    get_text(user_lang, 'achievement_earned', achievement)
                )
    
    except Exception as e:
        logger.error(f"Error applying referral code: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def level(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /level command - show level information."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        level_data = get_user_level(user.id)
        level_name = get_level_name(level_data['level'])
        
        # Level icon
        level_icon = "🏆" if level_data['level'] >= 9 else "💎" if level_data['level'] >= 7 else "🥇" if level_data['level'] >= 5 else "🥈" if level_data['level'] >= 3 else "🥉"
        
        message = get_text(user_lang, 'level_info',
                          level_icon,
                          level_data['level'],
                          level_name,
                          level_data['total_tasks'],
                          level_data['experience_points'],
                          level_data['weekly_tasks'])
        
        await update.message.reply_text(message, parse_mode='Markdown')
    
    except Exception as e:
        logger.error(f"Error in level command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def achievements(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /achievements command - show user achievements."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        user_achievements = get_user_achievements(user.id)
        
        if not user_achievements:
            message = get_text(user_lang, 'no_achievements')
        else:
            achievement_list = []
            for achievement_type, achievement_name, earned_at in user_achievements:
                achievement_list.append(f"• {achievement_name}")
            
            message = get_text(user_lang, 'achievements_list',
                              len(user_achievements),
                              '\n'.join(achievement_list))
        
        await update.message.reply_text(message, parse_mode='Markdown')
    
    except Exception as e:
        logger.error(f"Error in achievements command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def profile(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /profile command - show user profile."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        profile_data = get_user_profile(user.id)
        
        if not profile_data:
            await update.message.reply_text("❌ Profil bulunamadı!" if user_lang == 'tr' else "❌ Profile not found!")
            return
        
        # Title display
        title_display = f"👑 {profile_data['profile_title']}\n" if profile_data['profile_title'] else ""
        
        # Level info
        level_name = get_level_name(profile_data['level'])
        level_icon = "🏆" if profile_data['level'] >= 9 else "💎" if profile_data['level'] >= 7 else "🥇" if profile_data['level'] >= 5 else "🥈" if profile_data['level'] >= 3 else "🥉"
        
        # Premium status
        premium_info = ""
        if profile_data['premium_until']:
            premium_info = get_text(user_lang, 'premium_status', profile_data['premium_until'])
        
        message = get_text(user_lang, 'profile_info',
                          profile_data['username'],
                          title_display,
                          level_icon,
                          profile_data['level'],
                          level_name,
                          profile_data['coin'],
                          profile_data['total_tasks'],
                          profile_data['experience_points'],
                          profile_data['referral_count'],
                          profile_data['achievements_count'],
                          premium_info)
        
        await update.message.reply_text(message, parse_mode='Markdown')
    
    except Exception as e:
        logger.error(f"Error in profile command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def shop(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /shop command - show shop items."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        from database import get_user_coins
        user_coins = get_user_coins(user.id)
        
        message = get_text(user_lang, 'shop_menu', user_coins)
        
        # Create inline keyboard for shop items
        keyboard = []
        items = get_shop_items()
        
        for item in items:
            keyboard.append([InlineKeyboardButton(
                f"{item['name']} - {item['cost']} coin",
                callback_data=f"shop_{item['id']}"
            )])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(message, reply_markup=reply_markup, parse_mode='Markdown')
    
    except Exception as e:
        logger.error(f"Error in shop command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def handle_shop_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle shop item purchase callbacks."""
    query = update.callback_query
    user = query.from_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        await query.answer()
        
        if query.data.startswith('shop_'):
            item_id = query.data.replace('shop_', '')
            success, message = purchase_item(user.id, item_id)
            
            await query.edit_message_text(message)
            
            if success:
                # Check for achievements
                achievements = check_achievements(user.id)
                for achievement in achievements:
                    await context.bot.send_message(
                        user.id,
                        get_text(user_lang, 'achievement_earned', achievement)
                    )
    
    except Exception as e:
        logger.error(f"Error in shop callback: {e}")
        await query.edit_message_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def lottery(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /lottery command - buy lottery ticket."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        success, message = buy_lottery_ticket(user.id)
        await update.message.reply_text(message)
        
        if success:
            # Check for achievements
            achievements = check_achievements(user.id)
            for achievement in achievements:
                await update.message.reply_text(
                    get_text(user_lang, 'achievement_earned', achievement)
                )
    
    except Exception as e:
        logger.error(f"Error in lottery command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def dice(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /dice command - dice game."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    bet_amount = 10  # Default bet
    if context.args and context.args[0].isdigit():
        bet_amount = int(context.args[0])
        bet_amount = max(1, min(bet_amount, 100))  # Limit bet
    
    try:
        success, result_message, user_roll, bot_roll = play_dice_game(user.id, bet_amount)
        
        if user_roll > 0 and bot_roll > 0:
            if user_roll > bot_roll:
                message = get_text(user_lang, 'dice_win', user_roll, bot_roll, bet_amount * 2)
            elif user_roll < bot_roll:
                message = get_text(user_lang, 'dice_lose', user_roll, bot_roll, bet_amount)
            else:
                message = get_text(user_lang, 'dice_tie', user_roll, bot_roll)
        else:
            message = result_message
        
        await update.message.reply_text(message)
    
    except Exception as e:
        logger.error(f"Error in dice command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def wheel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /wheel command - wheel of fortune."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        success, result_message, amount = spin_wheel(user.id)
        
        if success:
            message = get_text(user_lang, 'wheel_result', result_message)
        else:
            message = result_message
        
        await update.message.reply_text(message)
    
    except Exception as e:
        logger.error(f"Error in wheel command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def weekly(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /weekly command - weekly leaderboard."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        leaderboard = get_weekly_leaderboard()
        
        if not leaderboard:
            await update.message.reply_text(
                "Henüz haftalık lider tablosu yok." if user_lang == 'tr' else "No weekly leaderboard yet."
            )
            return
        
        leaderboard_text = ""
        for i, (username, weekly_tasks, level) in enumerate(leaderboard, 1):
            medal = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else f"{i}."
            leaderboard_text += f"{medal} @{username} - {weekly_tasks} görev (Seviye {level})\n"
        
        message = get_text(user_lang, 'weekly_leaderboard', leaderboard_text)
        await update.message.reply_text(message, parse_mode='Markdown')
    
    except Exception as e:
        logger.error(f"Error in weekly command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /help command - show help menu."""
    user = update.effective_user
    user_lang = context.user_data.get('language', 'tr')
    
    try:
        message = get_text(user_lang, 'help_menu')
        await update.message.reply_text(message, parse_mode='Markdown')
    
    except Exception as e:
        logger.error(f"Error in help command: {e}")
        await update.message.reply_text("❌ Bir hata oluştu!" if user_lang == 'tr' else "❌ An error occurred!")

# Enhanced task completion with level system
async def enhanced_task_completion(user_id, user_lang):
    """Enhanced task completion with level and achievement checks."""
    try:
        # Update level
        level_up, new_level = update_user_level(user_id, task_completed=True)
        
        # Check achievements
        achievements = check_achievements(user_id)
        
        messages = []
        
        # Level up message
        if level_up:
            level_name = get_level_name(new_level)
            messages.append(get_text(user_lang, 'level_up', new_level, level_name))
        
        # Achievement messages
        for achievement in achievements:
            messages.append(get_text(user_lang, 'achievement_earned', achievement))
        
        return messages
        
    except Exception as e:
        logger.error(f"Error in enhanced task completion: {e}")
        return []